insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Руководитель ПСИП-Пилот', '/klt-auth/mainmenu', 'sip-ippz', 'read'
where not exists (select id
                  from casbin_rule
                  where ptype = 'p'
                    and v0 = 'Руководитель ПСИП-Пилот'
                    and v1 = '/klt-auth/mainmenu'
                    and v2 = 'sip-ippz'
                    and v3 = 'read');

insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Региональный менеджер ПСИП-Пилот', '/klt-auth/mainmenu', 'sip-ippz', 'read'
where not exists (select id
                  from casbin_rule
                  where ptype = 'p'
                    and v0 = 'Региональный менеджер ПСИП-Пилот'
                    and v1 = '/klt-auth/mainmenu'
                    and v2 = 'sip-ippz'
                    and v3 = 'read');

insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Инспектор ПСИП-Пилот', '/klt-auth/mainmenu', 'sip-ippz', 'read'
where not exists (select id
                  from casbin_rule
                  where ptype = 'p'
                    and v0 = 'Инспектор ПСИП-Пилот'
                    and v1 = '/klt-auth/mainmenu'
                    and v2 = 'sip-ippz'
                    and v3 = 'read');

insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Инспектор ОСИП ЮЛ', '/klt-auth/mainmenu', 'sip-ippz', 'read'
where not exists (select id
                  from casbin_rule
                  where ptype = 'p'
                    and v0 = 'Инспектор ОСИП ЮЛ'
                    and v1 = '/klt-auth/mainmenu'
                    and v2 = 'sip-ippz'
                    and v3 = 'read');

insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Инспектор СИП (внебаланс)', '/klt-auth/mainmenu', 'sip-ippz', 'read'
where not exists (select id
                  from casbin_rule
                  where ptype = 'p'
                    and v0 = 'Инспектор СИП (внебаланс)'
                    and v1 = '/klt-auth/mainmenu'
                    and v2 = 'sip-ippz'
                    and v3 = 'read');

insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Руководитель ОСИП - пилот ПЦП', '/klt-auth/mainmenu', 'sip-ippz', 'read'
where not exists (select id
                  from casbin_rule
                  where ptype = 'p'
                    and v0 = 'Руководитель ОСИП - пилот ПЦП'
                    and v1 = '/klt-auth/mainmenu'
                    and v2 = 'sip-ippz'
                    and v3 = 'read');

insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Региональный менеджер ОСИП - пилот ПЦП', '/klt-auth/mainmenu', 'sip-ippz', 'read'
where not exists (select id
                  from casbin_rule
                  where ptype = 'p'
                    and v0 = 'Региональный менеджер ОСИП - пилот ПЦП'
                    and v1 = '/klt-auth/mainmenu'
                    and v2 = 'sip-ippz'
                    and v3 = 'read');

insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Инспектор ОСИП - пилот ПЦП', '/klt-auth/mainmenu', 'sip-ippz', 'read'
where not exists (select id
                  from casbin_rule
                  where ptype = 'p'
                    and v0 = 'Инспектор ОСИП - пилот ПЦП'
                    and v1 = '/klt-auth/mainmenu'
                    and v2 = 'sip-ippz'
                    and v3 = 'read');