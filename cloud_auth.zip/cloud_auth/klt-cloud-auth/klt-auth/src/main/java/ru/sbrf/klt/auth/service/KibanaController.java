package ru.sbrf.klt.auth.service;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.ExpiredJwtException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sbrf.klt.auth.model.SudirToken;
import ru.sbrf.klt.auth.model.User;
import ru.sbrf.klt.auth.model.UserLoggedInEvent;
import ru.sbrf.klt.auth.store.UserStore;

import java.time.Instant;
import java.util.Base64;
import java.util.Date;
import java.util.Set;

import static java.util.Objects.isNull;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/auth_kibana")
public class KibanaController {

    private final UserStore userStore;
    private final JwtService jwtService;
    private final ObjectMapper objectMapper;
    private final KafkaEventPublisher kafkaEventPublisher;

    public static final String ACCESS_COOKIE = "access_cookie";
    public static final String ACCESS_TOKEN = "access_token";
    private static final String AUTHORIZATION_HTTP_HEADER = "Authorization";
    private static final String BEARER_PREFIX = "Bearer ";


    private static final String ADMIN = "Администратор";
    private static final String BUSINESS_ANALYST = "Бизнес-аналитик";
    private static final Set<String> acceptRoles = Set.of(ADMIN, BUSINESS_ANALYST);

    /**
     * Generates tokens for `userNameHeader` if no cookies are set
     * Otherwise verify tokens and reset them if expired
     *
     * @param authorizationHeader -  standard authorization header
     * @param accessToken         - access token if exists
     * @return http response with headers
     */
    @GetMapping
    public ResponseEntity<Object> setJwtToken(@RequestHeader(name = AUTHORIZATION_HTTP_HEADER) String authorizationHeader,
                                              @CookieValue(value = ACCESS_TOKEN, defaultValue = "") String accessToken) {

        SudirToken sudirToken = extractSudirTokenFromAuthorizationHeader(authorizationHeader);
        log.info("Setting token for user [{}, {}]", sudirToken.getSubject(), sudirToken.getPdi());

        User user = userStore.findByIdIgnoreCaseOrSberPdi(sudirToken.getSubject(), sudirToken.getPdi());

        if (isNull(user)) {
            log.error("User [{}, {}] not found", sudirToken.getSubject(), sudirToken.getPdi());
            return unauthorized();
        }

        if (user.getRoles().stream().noneMatch(acceptRoles::contains)) {
            log.info("User {} not roles for kibana ", user.getId());
            return forbidden();
        }

        if (accessToken.isEmpty()) {
            log.debug("User {} signed in. Generating new tokens...", user.getId());
            JwtToken jwtToken = jwtService.generateTokenPair(user, sudirToken.getExpiry());
            kafkaEventPublisher.publish(new UserLoggedInEvent(user));
            return refreshAccessToken(jwtToken.getAccessToken());
        }

        try {
            if (jwtService.isValidTokenForUser(accessToken, user.getId())) {
                return tokenVerified(accessToken);
            }
        } catch (ExpiredJwtException e) {
            try {
                JwtToken newTokens = jwtService.refreshToken(user, sudirToken.getExpiry());
                return refreshAccessToken(newTokens.getAccessToken());
            } catch (IllegalArgumentException e2) {
                log.error("Could not refresh token for {}", user.getId());
                return unauthorized();
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return unauthorized();
        }

        return unauthorized();
    }

    private ResponseEntity<Object> tokenVerified(String accessToken) {
        return ResponseEntity.ok()
                             .header(ACCESS_TOKEN, accessToken)
                             .build();
    }

    private ResponseEntity<Object> unauthorized() {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    private ResponseEntity<Object> forbidden() {
        return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
    }

    private ResponseEntity<Object> refreshAccessToken(String accessToken) {
        return ResponseEntity.ok()
                             .header(ACCESS_TOKEN, accessToken)
                             .header(ACCESS_COOKIE, jwtService.accessTokenAsCookieString(ACCESS_TOKEN, accessToken))
                             .build();
    }

    private SudirToken extractSudirTokenFromAuthorizationHeader(String headerValue) {
        if (headerValue != null && headerValue.strip().startsWith(BEARER_PREFIX)) {
            String token = headerValue.strip().substring(BEARER_PREFIX.length());
            String payload = new String(Base64.getUrlDecoder().decode(
                    token.split("\\.")[1]
            ));
            log.debug(payload);
            try {
                JsonNode rootNode = objectMapper.readTree(payload);
                String subject = rootNode.get("sub").asText();
                String pdi = rootNode.get("sberpdi").asText();
                long expiry = rootNode.get("exp").asLong() + jwtService.getDeltaExpAccessToken();
                return new SudirToken(subject, pdi, Date.from(Instant.ofEpochSecond(expiry)));
            } catch (JacksonException e) {
                log.error("Could not parse authorization header {}, {}", headerValue, e.getMessage());
                throw new IllegalArgumentException("Could not parse authorization header");
            }
        } else {
            throw new IllegalArgumentException();
        }
    }
}


