package ru.sbrf.klt.auth.mainmenu.web;

import org.casbin.jcasbin.main.Enforcer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.sbrf.klt.auth.casbin.CasbinAuthDomains;
import ru.sbrf.klt.auth.mainmenu.persistence.MainMenuItem;
import ru.sbrf.klt.auth.mainmenu.persistence.MainMenuItemDao;

import java.util.ArrayList;
import java.util.List;


/**
 * {
 * "modules": [
 * {
 * "title": "Урегулирование",
 * "id": "settlement"
 * }
 * ]
 * }
 */

@RestController
@RequestMapping("/api/main/v1/")
public class MainMenuController {

    @Autowired
    Enforcer enforcer;

    @Autowired
    MainMenuItemDao mainMenuItemDao;


    @GetMapping(value = "/user-config")
    public ResponseEntity<MainMenuDto> userConfig() {

        String sberPdi = ((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getUsername();

        List<MainMenuItem> menuItems = mainMenuItemDao.getAllMenuItems();
        List<String> allowedObjectKeys =
                enforcer.getImplicitPermissionsForUserInDomain(sberPdi, CasbinAuthDomains.MAIN_MAENU_DOMAIN)
                        .stream().map(perm -> perm.get(2))
                        .toList();
        List<MainMenuItem> availableItems = menuItems.stream().filter(
                it -> allowedObjectKeys.contains(it.id())
        ).toList();

        MainMenuDto menuDto = new MainMenuDto(new ArrayList<>());
        menuDto.modules().addAll(
                availableItems.stream()
                        .map(it -> new MainMenuDto.Item(it.id(), it.displayName()))
                        .toList()
        );

        return ResponseEntity.ok(menuDto);
    }
}
