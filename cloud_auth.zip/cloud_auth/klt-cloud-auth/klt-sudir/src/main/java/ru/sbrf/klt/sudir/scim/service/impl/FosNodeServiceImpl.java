package ru.sbrf.klt.sudir.scim.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.sber.sudir.scim.agent.api.exception.ScimException;
import ru.sber.sudir.scim.agent.api.model.SudirFosNode;
import ru.sber.sudir.scim.agent.api.service.FosNodeService;
import ru.sbrf.klt.sudir.scim.mapper.KalitaSudirMapper;
import ru.sbrf.klt.sudir.kalita.repository.KalitaDictFosRepository;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Имплементация сервиса зон
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class FosNodeServiceImpl implements FosNodeService {

    private final KalitaDictFosRepository dictRepository;
    private final KalitaSudirMapper sudirMapper;

    /**
     * Получить страницу зон
     *
     * @param start - стартовая позиция
     * @param count - количество зон на странице
     * @return - List<SudirFosNode> страница зон
     * @throws ScimException
     */
    @Override
    @Transactional
    public List<SudirFosNode> getPage(int start, int count) throws ScimException {
        log.debug("getPage: start {} count {}", start, count);
        return dictRepository.getFosPage(start - 1, count)
                             .map(sudirMapper::of)
                             .collect(Collectors.toList());
    }

    /**
     * Получить количество зон в таблице SUDIR_ZONE
     *
     * @return - количество зон
     * @throws ScimException
     */
    @Override
    public int getCount() throws ScimException {
        return dictRepository.getFosCount();
    }
}