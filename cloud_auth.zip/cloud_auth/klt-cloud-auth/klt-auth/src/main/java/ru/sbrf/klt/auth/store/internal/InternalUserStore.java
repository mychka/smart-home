package ru.sbrf.klt.auth.store.internal;

import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.sbrf.klt.auth.model.User;
import ru.sbrf.klt.auth.model.UserCreatedEvent;
import ru.sbrf.klt.auth.model.UserUpdatedEvent;
import ru.sbrf.klt.auth.service.KafkaEventPublisher;
import ru.sbrf.klt.auth.store.UserStore;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static java.util.Objects.isNull;
import static ru.sbrf.klt.auth.store.internal.Action.CREATE;
import static ru.sbrf.klt.auth.store.internal.Action.UPDATE;

@Component
@Primary
public class InternalUserStore implements UserStore {

    private static final Logger log = LoggerFactory.getLogger(InternalUserStore.class);

    private final UserStore externalStore;
    private final KafkaEventPublisher kafkaEventPublisher;
    private final InternalUserStoreDao internalUserStoreDao;
    private final ArrayBlockingQueue<User> updateQueue = new ArrayBlockingQueue<>(1000);
    private final ExecutorService executorService;

    public InternalUserStore(@Qualifier("Kalita") UserStore externalStore,
                             KafkaEventPublisher kafkaEventPublisher,
                             InternalUserStoreDao internalUserStoreDao) {
        this.externalStore = externalStore;
        this.kafkaEventPublisher = kafkaEventPublisher;
        this.internalUserStoreDao = internalUserStoreDao;
        executorService = Executors.newSingleThreadExecutor();
        executorService.submit(() -> {
            log.info("User updater has been started");
            while (!Thread.currentThread().isInterrupted()) {
                updateUserFromExternalSource();
            }
            log.info("User updater has been stopped");
        });
    }

    @PreDestroy
    void stopConsumers() throws InterruptedException {
        executorService.shutdownNow();
        executorService.awaitTermination(20, TimeUnit.SECONDS);
    }

    private void updateUserFromExternalSource() {
        try {
            User user = updateQueue.take();
            try {
                log.debug("Request to update user id = {}, sber pdi = {}", user.getId(), user.getSberPdi());
                User findUser = externalStore.findByIdIgnoreCaseOrSberPdi(user.getId(), user.getSberPdi());
                findUser.setId(user.getId());
                findUser.setSberPdi(user.getSberPdi());
                createOrUpdateUser(findUser);
            } catch (Exception e) {
                log.error("Could not update user id = {}, sber pdi = {}, message = {}", user.getId(), user.getSberPdi(), e.getMessage());
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    @Override
    @Transactional
    public User findByIdIgnoreCaseOrSberPdi(String id, String sberPdi) {
        User internalUser = internalUserStoreDao.findBySberPdi(sberPdi);
        if (isNull(internalUser)) {
            User externalUser = externalStore.findByIdIgnoreCaseOrSberPdi(id, sberPdi);
            if (isNull(externalUser)) {
                log.error("Пользователь id:{} pdi:{} нигде не найден.", id, sberPdi);
                return null;
            } else {
                externalUser.setId(id);
                externalUser.setSberPdi(sberPdi);
                createOrUpdateUser(externalUser);
            }
            log.info("Пользователь id:{} pdi:{} найден в БД Калиты ", id, sberPdi);
            return externalUser;
        } else {
            // Асинхронная синхронизация запрошенного пользователя с внешним хранилищем
            User syncUser = new User();
            syncUser.setId(id);
            syncUser.setSberPdi(internalUser.getSberPdi());
            boolean isAdded = updateQueue.add(syncUser);
            if (!isAdded) {
                log.warn("Could not add user id = {}, sber pdi = {} to update queue", syncUser.getId(), syncUser.getSberPdi());
            }
            log.info("Пользователь id:{} pdi:{} найден во внутреннем хранилище", id, sberPdi);
        }
        return internalUser;
    }

    private void createOrUpdateUser(User user) {
        Action action = internalUserStoreDao.createOrUpdateUser(user);
        if (action.equals(UPDATE)) {
            kafkaEventPublisher.publish(new UserUpdatedEvent(user));
        } else if (action.equals(CREATE)) {
            kafkaEventPublisher.publish(new UserCreatedEvent(user));
        }
    }
}
