package ru.sbrf.klt.sudir.kalita.service;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import ru.sber.sudir.scim.agent.api.model.SudirUser;
import ru.sbrf.klt.sudir.kalita.mapper.GenericAccountMapper;
import ru.sbrf.klt.sudir.kalita.xml.*;

@Slf4j
@AllArgsConstructor
public class KalitaSudirService extends WebServiceGatewaySupport {

    private final GenericAccountMapper genericAccountMapper=new GenericAccountMapper();

    /**
     * getUser по ID и по Login (id=username)
     */
    public SudirUser getUserById(String id) {
        GetAccountListById request = new GetAccountListById();
        request.setAccountId(id);
        GetAccountListByIdResponse response = (GetAccountListByIdResponse) getWebServiceTemplate().marshalSendAndReceive(
                request);
        if (response.getGetAccountListByIdReturn().isEmpty()) {
            return null;
        }
        return genericAccountMapper.toEntity(response.getGetAccountListByIdReturn().get(0));

    }

    /**
     * Создание пользователя.
     */
    public void createUser(SudirUser sudirUser) {
        CreateAccount request = new CreateAccount();
        request.setAccountInfo(genericAccountMapper.fromEntity(sudirUser));
        CreateAccountResponse response = (CreateAccountResponse) getWebServiceTemplate().marshalSendAndReceive(
                request);
    }

    /**
     * Редактирование пользователя
     */
    public void modifyUser(SudirUser sudirUser) {
        ModifyAccount request = new ModifyAccount();
        request.setAccountInfo(genericAccountMapper.fromEntity(sudirUser));
        ModifyAccountResponse response = (ModifyAccountResponse) getWebServiceTemplate().marshalSendAndReceive(
                request);
    }

    /**
     * Блокировка пользователя
     */
    public void markSuspend(String id) {
        SuspendAccount request = new SuspendAccount();
        request.setAccountId(id);
        SuspendAccountResponse response = (SuspendAccountResponse) getWebServiceTemplate().marshalSendAndReceive(
                request);
    }

}
