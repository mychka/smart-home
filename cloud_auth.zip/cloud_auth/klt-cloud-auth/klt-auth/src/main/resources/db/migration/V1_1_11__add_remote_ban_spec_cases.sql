insert into user_main_menu select 'special-cases','/special-cases', 'Спецкейсы'
    where not exists (select id from user_main_menu where id ='special-cases');
insert into user_main_menu select 'bankruptcy','/bankruptcy', 'Банкротство'
    where not exists (select id from user_main_menu where id ='bankruptcy');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'ЦСДВ Сотрудник контроля качества', '/klt-auth/mainmenu', 'remote', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'ЦСДВ Сотрудник контроля качества' and v1 = '/klt-auth/mainmenu' and v2 = 'remote' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'ЦСДВ Сотрудник на удаленке', '/klt-auth/mainmenu', 'remote', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'ЦСДВ Сотрудник на удаленке' and v1 = '/klt-auth/mainmenu' and v2 = 'remote' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Администратор', '/klt-auth/mainmenu', 'bankruptcy', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Администратор' and v1 = '/klt-auth/mainmenu' and v2 = 'bankruptcy' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Бизнес-аналитик', '/klt-auth/mainmenu', 'special-cases', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Бизнес-аналитик' and v1 = '/klt-auth/mainmenu' and v2 = 'special-cases' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Администратор', '/klt-auth/mainmenu', 'special-cases', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Администратор' and v1 = '/klt-auth/mainmenu' and v2 = 'special-cases' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Аудитор', '/klt-auth/mainmenu', 'special-cases', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Аудитор' and v1 = '/klt-auth/mainmenu' and v2 = 'special-cases' and v3 = 'read');
