CREATE SEQUENCE IF NOT EXISTS casbin_sequence START 1;
CREATE TABLE casbin_rule(
    id int GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    ptype VARCHAR(100) NOT NULL,
    v0 VARCHAR(100),
    v1 VARCHAR(100),
    v2 VARCHAR(100),
    v3 VARCHAR(100),
    v4 VARCHAR(100),
    v5 VARCHAR(100)
);

-- доступы ролей к меню "Урегулирование"
insert into casbin_rule(ptype, v0, v1, v2, v3) values('p','Сотрудник ПУПЗ', '/klt-auth/mainmenu', 'settlement', 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3) values('p','Администратор', '/klt-auth/mainmenu', 'settlement', 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3) values('p','Ассистент сотрудника урегулирования ФЛ', '/klt-auth/mainmenu', 'settlement', 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3) values('p','Сотрудник урегулирования ФЛ', '/klt-auth/mainmenu', 'settlement', 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3) values('p','Руководитель ПУПЗ ТБ','/klt-auth/mainmenu', 'settlement', 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3) values('p','Аудитор', '/klt-auth/mainmenu', 'settlement', 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3) values('p','Бизнес-аналитик', '/klt-auth/mainmenu','settlement', 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3) values('p','ГЛ ЦУЗ Урегулирование Удаленный оператор', '/klt-auth/mainmenu', 'settlement', 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3) values('p','Сотрудник группы подготовки документов урегулирования ФЛ', '/klt-auth/mainmenu', 'settlement', 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3) values('p','Руководитель группы подготовки документов урегулирования', '/klt-auth/mainmenu', 'settlement', 'read');

-- доступы ролей к меню "СИП"
insert into casbin_rule(ptype, v0, v1, v2, v3) values('p', 'Инспектор ОСИП', '/klt-auth/mainmenu', 'sip', 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3) values('p', 'Руководитель ОСИП', '/klt-auth/mainmenu', 'sip', 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3) values('p', 'Аудитор', '/klt-auth/mainmenu', 'sip', 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3) values('p', 'Бизнес-аналитик', '/klt-auth/mainmenu', 'sip', 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3) values('p', 'Руководитель ОСИП', '/klt-auth/mainmenu', 'sip', 'read');

-- заполняем роли для всех доменов('*')
insert into casbin_rule(ptype, v0, v1, v2) select 'g', sber_pdi, role, '*' from user_role;