package ru.sbrf.klt.auth.store.internal;

import org.casbin.jcasbin.main.Enforcer;
import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.jdbc.Sql;
import ru.sbrf.klt.auth.AbstractTest;
import ru.sbrf.klt.auth.model.User;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static ru.sbrf.klt.auth.store.internal.Action.CREATE;
import static ru.sbrf.klt.auth.store.internal.Action.UPDATE;

class InternalUserStoreDaoITest extends AbstractTest {

    @Autowired
    InternalUserStoreDao internalUserStoreDao;
    @Autowired
    Enforcer enforcer;

    @BeforeEach
    void setup() {
        // Тестовые sql скрипты выполняются после загрузки Enforcer'а, принудительно подгружаем политики
        enforcer.loadPolicy();
    }

    @Test
    @DisplayName("При репликации нового пользователя из БД Калиты роли записываются в политики авторизации")
    void casbinGroupsAreCreatedOnUserReplication() {
        //given

        User testUser = Instancio.create(User.class);

        //when
        Action action = internalUserStoreDao.createOrUpdateUser(testUser);

        //then
        assertThat(action).isEqualTo(CREATE);

        User user = internalUserStoreDao.findBySberPdi(testUser.getSberPdi());
        assertThat(user)
                .isNotNull()
                .satisfies(user1 -> assertThat(user1.getRoles()).isNotEmpty());

        List<String> roles = enforcer.getRolesForUser(user.getSberPdi());
        assertThat(roles).containsExactlyInAnyOrderElementsOf(user.getRoles());
    }


    @Test
    @DisplayName("При обновлении ролей пользователя из БД Калиты, политики авторизации обновляются и синхронизированы с ролями")
    @Sql("/internal_store_scripts/test_user_sberpdi_1.sql")
    void casbinGroupsAreMergedOnUserUpdate() throws InterruptedException {
        //given
        User testUser = internalUserStoreDao.findBySberPdi("sberpdi_1");
        testUser.getRoles().remove("test_role_2");
        testUser.getRoles().add("test_role_4");

        //when
        Action action = internalUserStoreDao.createOrUpdateUser(testUser);

        //then
        assertThat(action).isEqualTo(UPDATE);

        User user = internalUserStoreDao.findBySberPdi("sberpdi_1");
        List<String> roles = enforcer.getRolesForUser(user.getSberPdi());
        assertThat(user.getRoles()).containsExactlyInAnyOrder("test_role_1", "test_role_3", "test_role_4");
        assertThat(roles).containsExactlyInAnyOrderElementsOf(user.getRoles());
    }
}