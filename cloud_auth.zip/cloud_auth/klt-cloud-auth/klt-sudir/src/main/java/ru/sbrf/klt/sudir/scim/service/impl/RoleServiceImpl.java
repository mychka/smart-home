package ru.sbrf.klt.sudir.scim.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.sber.sudir.scim.agent.api.exception.ScimException;
import ru.sber.sudir.scim.agent.api.model.SudirRole;
import ru.sber.sudir.scim.agent.api.service.RoleService;
import ru.sbrf.klt.sudir.scim.mapper.KalitaSudirMapper;
import ru.sbrf.klt.sudir.kalita.repository.KalitaDictRoleRepository;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Имплементация сервиса ролей RoleService -Обязательно!
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RoleServiceImpl implements RoleService {

    private final KalitaDictRoleRepository dictRepository;
    private final KalitaSudirMapper sudirMapper;

    /**
     * Получить страницу ролей
     *
     * @param start - стартовая позиция
     * @param count - количество ролей на странице
     * @return - List<SudirRole> - страница ролей
     */
    @Override
    @Transactional
    public List<SudirRole> getPage(int start, int count) throws ScimException {
        log.debug("getPage: start {} count {}", start, count);
        return dictRepository.getRolePage(start - 1, count)
                             .map(sudirMapper::of)
                             .collect(Collectors.toList());
    }

    /**
     * Получить количество ролей в таблице ACT_ID_GROUP в БК
     *
     * @return
     */
    @Override
    public int getCount() throws ScimException {
        return dictRepository.getRoleCount();
    }
}