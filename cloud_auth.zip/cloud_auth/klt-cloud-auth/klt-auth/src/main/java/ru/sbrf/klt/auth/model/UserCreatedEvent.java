package ru.sbrf.klt.auth.model;

import java.time.LocalDateTime;

public class UserCreatedEvent extends UserEvent {
    public static final String TYPE = "USER_CREATED";

    public UserCreatedEvent() {
        setType(TYPE);
        setTimestamp(LocalDateTime.now());
    }

    public UserCreatedEvent(User user) {
        this();
        setUser(user);
    }
}
