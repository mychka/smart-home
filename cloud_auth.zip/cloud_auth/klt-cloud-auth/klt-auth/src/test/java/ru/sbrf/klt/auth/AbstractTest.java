package ru.sbrf.klt.auth;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import ru.sbrf.klt.auth.service.KafkaEventPublisher;

@ActiveProfiles("test")
@SpringBootTest(classes = EmbeddedPostgresDataSourceConfig.class)
@Sql(scripts = "/internal_store_scripts/cleanup.sql", executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
public abstract class AbstractTest {

    @MockBean
    protected KafkaEventPublisher kafkaEventPublisher;
}
