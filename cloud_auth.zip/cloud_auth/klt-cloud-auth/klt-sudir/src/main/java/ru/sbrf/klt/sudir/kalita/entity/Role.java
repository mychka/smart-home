package ru.sbrf.klt.sudir.kalita.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "ROLE")
@Cacheable
public class Role {

    @Id
    @Column(name = "ID")
    private String id;

    @Column(name = "NAME")
    private String name;

    @Column(name = "IS_DELETED")
    private Boolean isDeleted;

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

}
