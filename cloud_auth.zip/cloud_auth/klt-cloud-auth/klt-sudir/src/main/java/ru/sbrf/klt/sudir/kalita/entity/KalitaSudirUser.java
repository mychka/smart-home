package ru.sbrf.klt.sudir.kalita.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.Where;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Entity
@Table(name = "ACT_ID_USER")
public class KalitaSudirUser {

    @Id
    @Column(name = "ID_")
    private String id;

    /**
     * Имя пользователя
     **/
    @Column(name = "FIRST_", nullable = false, length = 255)
    private String firstName;

    @Column(name = "SBER_PDI", nullable = false, length = 255)
    private String sberPdi;

    /**
     * Отчество пользователя
     **/
    @Column(name = "MIDDLE_NAME_", nullable = false, length = 255)
    private String middleName;

    /**
     * Фамилия пользователя
     **/
    @Column(name = "LAST_", nullable = false, length = 255)
    private String lastName;

    /**
     * Статус блокировки
     **/
    @Column(name = "IS_SUSPENDED", nullable = false, length = 2)
    private Boolean suspendStatus;


    /**
     * Email сотрудника
     */
    @OneToOne(cascade = {CascadeType.MERGE, CascadeType.PERSIST})
    @JoinColumn(name = "INTRABANK_EMAIL_ID")
    private IntrabankEmail intrabankEmail;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "REG_BANK_ID_")
    private RegionalBankCodeDict regBank;

    @ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH, CascadeType.PERSIST})
    @JoinTable(
            name = "ACT_ID_MEMBERSHIP",
            joinColumns = {@JoinColumn(name = "USER_ID_", referencedColumnName = "ID_"),},
            inverseJoinColumns = {@JoinColumn(name = "GROUP_ID_", referencedColumnName = "ID_")}
    )
    @Where(clause = "IS_DELETED_ = 0 and ID_ != '56'")
    private Set<Group> groups = new HashSet<>();

    /**
     * Табельный номер пользователя
     */
    @Column(name = "PERSONNEL_NUMBER", nullable = false, length = 30)
    private String employeeNumber;

    /**
     * Название должности пользователя
     **/
    @Column(name = "POSITION", nullable = false, length = 255)
    private String position;

    public Set<Group> getGroups() {
        return groups;
    }


    @Column(name = "IS_DELETED", nullable = false, length = 2)
    private Boolean is_deleted;

    public String getId() {
        return id;
    }

    public String getSberPdi() {
        return sberPdi;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public Boolean getSuspendStatus() {
        return suspendStatus;
    }

    public IntrabankEmail getIntrabankEmail() {
        return intrabankEmail;
    }

    public RegionalBankCodeDict getRegBank() {
        return regBank;
    }

    public String getEmployeeNumber() {
        return employeeNumber;
    }

    public String getPosition() {
        return position;
    }

    public Boolean getIs_deleted() {
        return is_deleted;
    }

    @Transient
    public List<String> getRoleId() {
        return groups.stream()
                .map(Group::getRoles).flatMap(Collection::stream)
                .map(Role::getId).distinct().collect(Collectors.toList());
    }

}
