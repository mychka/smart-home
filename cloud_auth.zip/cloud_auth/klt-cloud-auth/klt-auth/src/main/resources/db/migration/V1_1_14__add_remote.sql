insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'ЦСДВ Сотрудник ИРК', '/klt-auth/mainmenu', 'remote', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'ЦСДВ Сотрудник ИРК' and v1 = '/klt-auth/mainmenu' and v2 = 'remote' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Главный специалист сопровождения процедуры банкротства', '/klt-auth/mainmenu', 'remote', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Главный специалист сопровождения процедуры банкротства' and v1 = '/klt-auth/mainmenu' and v2 = 'remote' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Специалист сопровождения процедуры банкротства', '/klt-auth/mainmenu', 'remote', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Специалист сопровождения процедуры банкротства' and v1 = '/klt-auth/mainmenu' and v2 = 'remote' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник ПУПЗ', '/klt-auth/mainmenu', 'remote', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник ПУПЗ' and v1 = '/klt-auth/mainmenu' and v2 = 'remote' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник группы подготовки документов урегулирования ФЛ', '/klt-auth/mainmenu', 'remote', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник группы подготовки документов урегулирования ФЛ' and v1 = '/klt-auth/mainmenu' and v2 = 'remote' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Оператор КЦ: индивидуальная обработка клиентов ПС', '/klt-auth/mainmenu', 'remote', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Оператор КЦ: индивидуальная обработка клиентов ПС' and v1 = '/klt-auth/mainmenu' and v2 = 'remote' and v3 = 'read');
