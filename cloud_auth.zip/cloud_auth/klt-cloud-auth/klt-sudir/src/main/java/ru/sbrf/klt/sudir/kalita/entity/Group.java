package ru.sbrf.klt.sudir.kalita.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Where;

import java.util.Set;

@Entity
@Table(name = "ACT_ID_GROUP")
@Cacheable
public class Group {

    @Id
    @Column(name = "ID_")
    private String id;

    @ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH, CascadeType.PERSIST})
    @JoinTable(
            name = "ACT_ID_GROUP_TO_ROLE",
            joinColumns = {@JoinColumn(name = "GROUP_ID_", referencedColumnName = "ID_"),},
            inverseJoinColumns = {@JoinColumn(name = "ROLE_ID_", referencedColumnName = "ID")}
    )
    @Where(clause = "is_deleted = 0")
    @BatchSize(size = 10)
    private Set<Role> roles;

    @Column(name = "NAME_")
    private String name;

    @Basic
    @Column(name = "IS_DELETED_")
    private Boolean isDeleted;

    @Basic
    @Column(name = "IS_ENABLED_")
    private Boolean isEnabled;

    public String getId() {
        return id;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public String getName() {
        return name;
    }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public Boolean getIsEnabled() {
        return isEnabled;
    }

}
