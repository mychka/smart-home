package ru.sbrf.klt.auth.mainmenu.security;

import io.jsonwebtoken.Claims;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

import java.util.*;

public class JwtAuthentication implements Authentication {
    private boolean authenticated;
    private final String login;
    private final String sberpdi;
    private final String firstName;
    private final String lastName;
    private final User principal;

    private final List<String> roles;

    JwtAuthentication(Claims claims) {
        this.login = claims.getSubject();
        this.sberpdi = claims.get("pdi", String.class);
        this.firstName = claims.get("firstName", String.class);
        this.lastName = claims.get("lastName", String.class);
        this.roles = claims.get("roles", ArrayList.class);
        this.principal = new User(this.sberpdi,
                "",
                roles.stream().map(SimpleGrantedAuthority::new).toList());
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return principal.getAuthorities();
    }

    @Override
    public Object getCredentials() {
        return principal.getPassword();
    }

    @Override
    public Object getDetails() {
        return null;
    }

    @Override
    public Object getPrincipal() {
        return principal;
    }

    @Override
    public boolean isAuthenticated() {
        return authenticated;
    }

    @Override
    public void setAuthenticated(boolean isAuthenticated) throws IllegalArgumentException {
        this.authenticated = isAuthenticated;
    }

    @Override
    public String getName() {
        return firstName + " " + lastName;
    }
}
