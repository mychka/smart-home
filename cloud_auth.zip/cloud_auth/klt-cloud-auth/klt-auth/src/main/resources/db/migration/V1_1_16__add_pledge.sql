insert into user_main_menu select 'pledge','/pledge', 'Имущество'
where not exists (select id from user_main_menu where id ='pledge');


insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Бизнес-аналитик', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Бизнес-аналитик' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник ПУПЗ', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник ПУПЗ' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Руководитель ПУПЗ', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Руководитель ПУПЗ' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Руководитель ПУПЗ ТБ', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Руководитель ПУПЗ ТБ' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник ПУПЗ ЮЛ', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник ПУПЗ ЮЛ' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Руководитель группы урегулирования', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Руководитель группы урегулирования' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');