package ru.sbrf.klt.sudir.scim.mapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.sber.sudir.scim.agent.api.model.SudirFosNode;
import ru.sber.sudir.scim.agent.api.model.SudirRole;
import ru.sber.sudir.scim.agent.api.model.SudirUser;
import ru.sbrf.klt.sudir.kalita.entity.Group;
import ru.sbrf.klt.sudir.kalita.entity.KalitaSudirUser;
import ru.sbrf.klt.sudir.kalita.entity.RegionalBankCodeDict;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class KalitaSudirMapper {

    private static final String EMPTY = "unknown";

    public SudirUser of(KalitaSudirUser user) {
        SudirUser sudirUser = new SudirUser();
        sudirUser.setActive(!user.getSuspendStatus());
        sudirUser.setId(user.getSberPdi());
        sudirUser.setUserName(user.getSberPdi());
        sudirUser.setFamilyName(user.getLastName());
        sudirUser.setDisplayName(user.getLastName());
        sudirUser.setGivenName(user.getFirstName());
        sudirUser.setMiddleName(user.getMiddleName());
        sudirUser.setTitle(user.getPosition());
        if (user.getIntrabankEmail() != null) {
            sudirUser.setIntEmail(user.getIntrabankEmail().getIntrabankEmail() == null ? EMPTY : user.getIntrabankEmail().getIntrabankEmail());
        }
        sudirUser.setEmployeeNumber(user.getEmployeeNumber());
        sudirUser.setRoles(user.getGroups().stream().map(Group::getId).distinct().collect(Collectors.toList()));
        sudirUser.setFosNodes(List.of(user.getRegBank().getCode()));
        return sudirUser;
    }

    /**
     * Fos из БД
     **/
    public SudirFosNode of(RegionalBankCodeDict dict) {
        SudirFosNode sudirFos = new SudirFosNode();
        sudirFos.setId(dict.getCode());
        sudirFos.setDisplayName(dict.getDescription());
        sudirFos.setArchive(dict.getIsDeleted());
        return sudirFos;
    }

    /**
     * Роли из БД
     **/
    public SudirRole of(Group dict) {
        SudirRole sudirFos = new SudirRole();
        sudirFos.setId(dict.getId());
        sudirFos.setDisplayName(dict.getName());
        if(dict.getName().equals("Пользователь удален")){
            sudirFos.setArchive(true);
        }else {
            sudirFos.setArchive(dict.getIsDeleted());
        }
        return sudirFos;
    }
}