package ru.sbrf.klt.sudir.kalita.mapper;

import lombok.extern.slf4j.Slf4j;
import ru.sber.sudir.scim.agent.api.model.SudirUser;
import ru.sbrf.klt.sudir.kalita.dict.SudirConstants;
import ru.sbrf.klt.sudir.kalita.xml.ArrayOfGenericAttribute;
import ru.sbrf.klt.sudir.kalita.xml.ArrayOfXsdString;
import ru.sbrf.klt.sudir.kalita.xml.GenericAccountInfo;
import ru.sbrf.klt.sudir.kalita.xml.GenericAttribute;

import java.util.ArrayList;
import java.util.List;


@Slf4j
public class GenericAccountMapper {

    public SudirUser toEntity(GenericAccountInfo genericAccountInfo) {
        SudirUser sudirUser = new SudirUser();
        if (genericAccountInfo.getAttributes() != null) {
            if (genericAccountInfo.getAttributes().getItem() != null) {
                for (GenericAttribute genericAttribute : genericAccountInfo.getAttributes().getItem()) {
                    String genericAttributeName = genericAttribute.getName();

                    if (genericAttribute.getValues().getItem() != null && genericAttribute.getValues().getItem().size() > 0) {

                        String attributeFirstValue = genericAttribute.getValues().getItem().get(0);

                        switch (genericAttributeName) {
                            case SudirConstants.LOGIN:
                                String login = attributeFirstValue.trim();
                                if (sudirUser.getId() == null) {
                                    // createAccount
                                    sudirUser.setId(login);
                                }
                                sudirUser.setId(login);
                                sudirUser.setUserName(login);
                                break;

                            case SudirConstants.FIRST_NAME_ATTRIBUTE:
                                sudirUser.setGivenName(attributeFirstValue);
                                break;

                            case SudirConstants.LAST_NAME_ATTRIBUTE:
                                sudirUser.setFamilyName(attributeFirstValue);
                                //TODO DispayName
                                sudirUser.setDisplayName(attributeFirstValue);
                                break;

                            case SudirConstants.MIDDLE_NAME_ATTRIBUTE:
                                sudirUser.setMiddleName(attributeFirstValue);
                                break;

                            case SudirConstants.PERSONNEL_NUMBER:
                                if ((attributeFirstValue==null||attributeFirstValue.equals(""))) {
                                    sudirUser.setEmployeeNumber("");
                                } else {
                                    sudirUser.setEmployeeNumber(attributeFirstValue);
                                }
                                break;

                            case SudirConstants.EMAIL:
                                sudirUser.setIntEmail(attributeFirstValue);
                                break;

                            case SudirConstants.POSITION:
                                sudirUser.setTitle(attributeFirstValue);
                                break;

                            case SudirConstants.ACCOUNT_ACTIVE_ATTR:
                                sudirUser.setActive(SudirConstants.NOT_SUSPENDED.equals(attributeFirstValue));
                                break;

                            case SudirConstants.FOS:
                                List<String> fos = genericAttribute.getValues().getItem();
                                sudirUser.setFosNodes(fos);
                                break;

                            case SudirConstants.ROLE_CONTAINER:
                                List<String> roles = genericAttribute.getValues().getItem();
                                roles.remove("56");
                                sudirUser.setRoles(roles);
                                break;
                            default:
                                log.error("Unknown attribute {} occurred while mapping SudirUser {}", genericAttributeName, sudirUser.getId());
                        }
                    }
                }
            }
        }
        return sudirUser;
    }

    public GenericAccountInfo fromEntity(SudirUser user) {
        GenericAccountInfo genericAccountInfo = new GenericAccountInfo();
        genericAccountInfo.setAttributes(new ArrayOfGenericAttribute());
        addAttribute(genericAccountInfo, SudirConstants.LOGIN, user.getUserName());
        addAttribute(genericAccountInfo, SudirConstants.FIRST_NAME_ATTRIBUTE, user.getGivenName());
        addAttribute(genericAccountInfo, SudirConstants.LAST_NAME_ATTRIBUTE, user.getFamilyName());
        addAttribute(genericAccountInfo, SudirConstants.MIDDLE_NAME_ATTRIBUTE, user.getMiddleName());
        addAttribute(genericAccountInfo, SudirConstants.ACCOUNT_ACTIVE_ATTR, user.getActive() ? SudirConstants.NOT_SUSPENDED : SudirConstants.SUSPENDED);
        if (user.getFosNodes() != null) {
            addAttribute(genericAccountInfo, SudirConstants.FOS, user.getFosNodes().get(0)); //обязательное поле иначе не создается пользователь
        }
        addAttribute(genericAccountInfo, SudirConstants.PERSONNEL_NUMBER, user.getEmployeeNumber());
        addAttribute(genericAccountInfo, SudirConstants.EMAIL, user.getIntEmail() != null ? user.getIntEmail() : "");
        addAttribute(genericAccountInfo, SudirConstants.POSITION, user.getTitle() != null ? user.getTitle() : "");
        if (user.getRoles() != null && !user.getRoles().isEmpty()) {
            addAttribute(genericAccountInfo, user.getRoles());
        } else addAttribute(genericAccountInfo, new ArrayList<>());
        return genericAccountInfo;
    }

    public void addAttribute(GenericAccountInfo info, String key, String value) {
        info.getAttributes().getItem().add(buildGenericAttribute(key, value));
    }

    public void addAttribute(GenericAccountInfo info, List<String> rolse) {
        GenericAttribute genericAttribute = new GenericAttribute();
        genericAttribute.setName(SudirConstants.ROLE_CONTAINER);
        genericAttribute.setTypeId(SudirConstants.ATTR_TYPE_STRING);
        ArrayOfXsdString arrayOfXsdString = new ArrayOfXsdString();
        for (String role : rolse) {
            arrayOfXsdString.getItem().add(role);
        }
        genericAttribute.setValues(arrayOfXsdString);
        info.getAttributes().getItem().add(genericAttribute);
    }

    public GenericAttribute buildGenericAttribute(String key, String value) {
        GenericAttribute genericAttribute = new GenericAttribute();
        genericAttribute.setName(key);
        genericAttribute.setTypeId(SudirConstants.ATTR_TYPE_STRING);
        ArrayOfXsdString arrayOfXsdString = new ArrayOfXsdString();
        if (!(value==null||value.equals(""))) {
            arrayOfXsdString.getItem().add(value);
        }
        genericAttribute.setValues(arrayOfXsdString);
        return genericAttribute;
    }


}