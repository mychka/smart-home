package ru.sbrf.klt.auth.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import ru.sbrf.klt.auth.model.UserEvent;

@Slf4j
@Component
public class KafkaEventPublisher {

    @Value("${spring.kafka.topic.outbound.name}")
    private String outboundTopic;

    private final KafkaTemplate<String, String> kafka;
    private final ObjectMapper objectMapper;

    public KafkaEventPublisher(KafkaTemplate<String, String> kafkaTemplate, ObjectMapper objectMapper) {
        this.kafka = kafkaTemplate;
        this.objectMapper = objectMapper;
    }

    public void publish(UserEvent event) {
        try {
            String key = event.getUser().getSberPdi();
            String value = objectMapper.writeValueAsString(event);
            kafka.send(new ProducerRecord<>(outboundTopic, key, value));
            log.info("Publish event {} to topic {}:\n{}", event.getType(), outboundTopic, value);
        } catch (Exception e) {
            log.error(String.format("Could not publish user event %s for user %s", event.getType(), event.getUser().getId()), e);
        }
    }
}
