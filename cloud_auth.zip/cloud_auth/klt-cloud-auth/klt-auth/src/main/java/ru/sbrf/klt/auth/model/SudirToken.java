package ru.sbrf.klt.auth.model;

import java.util.Date;

public class SudirToken {

    String subject;
    String pdi;
    Date expiry;

    public SudirToken(String subject, String pdi, Date expiry) {
        this.subject = subject.toLowerCase();
        this.pdi = pdi.toLowerCase();
        this.expiry = expiry;
    }

    public String getSubject() {
        return subject;
    }

    public String getPdi() {
        return pdi;
    }

    public Date getExpiry() {
        return expiry;
    }


}
