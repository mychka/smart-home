package ru.sbrf.klt.sudir.kalita.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sbrf.klt.sudir.kalita.entity.Group;

import java.util.stream.Stream;


/**
 * Репозиторий спавочника ACT_ID_GROUP
 */
@Repository
public interface KalitaDictRoleRepository extends JpaRepository<Group, String> {

    /**
     * Получить значния справочника ACT_ID_GROUP
     *
     * @param offset - startIndex
     * @param limit  - размер окна
     * @return - поток Group
     */
    @Query(value = "select * from ACT_ID_GROUP u OFFSET :offset rows fetch next :limit rows only", nativeQuery = true)
    Stream<Group> getRolePage(@Param("offset") int offset, @Param("limit") int limit);

    /**
     * Получить количество записей справочника
     *
     * @return - int - количество активных пользователей
     */
    @Query("select count(u) from Group u")
    int getRoleCount();

}
