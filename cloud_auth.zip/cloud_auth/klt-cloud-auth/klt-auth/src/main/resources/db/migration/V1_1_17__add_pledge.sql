insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Руководитель команды управления реализации', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Руководитель команды управления реализации' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Руководитель группы принятия решений управления реализации', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Руководитель группы принятия решений управления реализации' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник принятия решений управления реализации', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник принятия решений управления реализации' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник по работе с экспертизами управления реализации', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник по работе с экспертизами управления реализации' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник по работе с обеспечением', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник по работе с обеспечением' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Руководитель группы реализации в ИП', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Руководитель группы реализации в ИП' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник реализации в ИП', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник реализации в ИП' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Руководитель группы реализации с баланса', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Руководитель группы реализации с баланса' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник реализации с баланса', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник реализации с баланса' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник подготовки ДКП и списания', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник подготовки ДКП и списания' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Ассистент реализации имущества', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Ассистент реализации имущества' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Руководитель группы реализации в банкротстве', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Руководитель группы реализации в банкротстве' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник реализации в банкротстве', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник реализации в банкротстве' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Руководитель группы сопровождения реализации', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Руководитель группы сопровождения реализации' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник постановки на баланс', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник постановки на баланс' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник оценки', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник оценки' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник экспертизы оценки', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник экспертизы оценки' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник сопровождения оплаты по имуществу', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник сопровождения оплаты по имуществу' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник сопровождения дебиторской задолженности по имуществу', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник сопровождения дебиторской задолженности по имуществу' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Руководитель группы операторов реализации', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Руководитель группы операторов реализации' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Сотрудник оператор реализации', '/klt-auth/mainmenu', 'pledge', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник оператор реализации' and v1 = '/klt-auth/mainmenu' and v2 = 'pledge' and v3 = 'read');