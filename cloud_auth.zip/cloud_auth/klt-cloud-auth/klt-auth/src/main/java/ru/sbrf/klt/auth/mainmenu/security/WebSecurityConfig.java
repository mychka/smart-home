package ru.sbrf.klt.auth.mainmenu.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import ru.sbrf.klt.auth.service.JwtService;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig {

    @Autowired
    JwtService jwtService;

    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return web -> web.ignoring().requestMatchers("/auth/**", "/auth_kibana/**", "/actuator/**","/config/**");
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.requiresChannel(c -> c.anyRequest().requiresInsecure())
            .cors(AbstractHttpConfigurer::disable)
            .csrf(AbstractHttpConfigurer::disable)
            .authorizeHttpRequests(registry -> registry.requestMatchers("/auth/**").permitAll())
            .authorizeHttpRequests(registry -> registry.requestMatchers("/auth_kibana/**").permitAll())
            .authorizeHttpRequests(registry -> registry.requestMatchers("/actuator/**").anonymous())
            .authorizeHttpRequests(registry -> registry.requestMatchers("/api/**").authenticated())
            .addFilterAfter(new JwtFilter(jwtService), UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }
}
