package ru.sbrf.klt.sudir.mapper;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import ru.sber.sudir.scim.agent.api.model.SudirUser;
import ru.sbrf.klt.sudir.AbstractTest;
import ru.sbrf.klt.sudir.kalita.mapper.GenericAccountMapper;
import ru.sbrf.klt.sudir.kalita.xml.GenericAccountInfo;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class GenericAccountMapperTest extends AbstractTest {

    private final GenericAccountMapper mapper = new GenericAccountMapper();

    @Test
    @DisplayName("Маппинг SudirUser в GenericAccountInfo и обратно")
    void testToGetSudirUserFromGenericAccountInfo() {
        SudirUser user = new SudirUser();
        user.setId("1");
        user.setUserName("1");
        user.setGivenName("Игорь");
        user.setMiddleName("Николаевич");
        user.setFamilyName("Иванович");
        user.setDisplayName("Иванович");
        user.setEmployeeNumber("123");
        user.setIntEmail("test@mail");
        user.setTitle("test@mail");
        user.setActive(true);
        List<String> roles = new ArrayList<>();
        roles.add("1");
        user.setRoles(roles);
        List<String> foses = new ArrayList<>();
        foses.add("99");
        user.setFosNodes(foses);
        GenericAccountInfo genAcc = mapper.fromEntity(user);
        SudirUser userFrom = mapper.toEntity(genAcc);
        assertEquals(user, userFrom);
    }

}
