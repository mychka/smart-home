package ru.sbrf.klt.auth.resource.controller;

import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController("sampleService")
public class RestServiceImpl {

    @GetMapping(value = "/admin", produces = MediaType.TEXT_PLAIN_VALUE)
    public String admin() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        return "Congrats " + authentication.getName() + "you are an administrator!";
    }

    @GetMapping(value = "/user", produces = MediaType.TEXT_PLAIN_VALUE)
    public String user() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        return "Hello " + authentication.getName() + "!";
    }
}