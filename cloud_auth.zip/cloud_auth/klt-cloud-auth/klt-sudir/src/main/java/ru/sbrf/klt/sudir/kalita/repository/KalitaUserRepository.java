package ru.sbrf.klt.sudir.kalita.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sbrf.klt.sudir.kalita.entity.KalitaSudirUser;

import java.util.stream.Stream;


/**
 * Репозиторий пользователей таблицы ACT_ID_USER
 */
@Repository
public interface KalitaUserRepository extends JpaRepository<KalitaSudirUser, String> {

    /**
     * Найти страницу активных пользователей
     *
     * @param offset - startIndex
     * @param limit  - размер окна
     * @return - поток KalitaSudirUser
     */
    @Query(value = "select * from ACT_ID_USER where is_deleted=0 and SBER_PDI is not null OFFSET (:offset) rows fetch next (:limit) rows only", nativeQuery = true)
    Stream<KalitaSudirUser> getUsersPage(@Param("offset") int offset, @Param("limit") int limit);

    /**
     * Получить количество активных пользователей
     *
     * @return - int - количество активных пользователей
     */
    @Query("select count(u) from KalitaSudirUser u where u.is_deleted=false and u.sberPdi is not null")
    int getUserCount();

}
