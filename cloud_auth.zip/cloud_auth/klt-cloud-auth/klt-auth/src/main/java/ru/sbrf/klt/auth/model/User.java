package ru.sbrf.klt.auth.model;

import java.math.BigDecimal;
import java.util.*;

public class User {

    public static final String DEFAULT_TIME_ZONE = "UTC+03:00";

    private String id;
    private String firstName;
    private String lastName;
    private String middleName;
    private String email;
    private boolean deleted;
    private String sberPdi;
    private String timeZone; // Часовой пояс
    private String workingDayStartTime; // Рабочее время с ...
    private String workingDayEndTime; // Рабочее время по ...
    private BigDecimal sumLimitFrom; // Лимит обработки по суммам задолженности от
    private BigDecimal sumLimitTo; // Лимит обработки по суммам задолженности до
    private String externalPhone; // Внешний номер телефона
    private String internalPhone; // Внутренний номер телефона
    private boolean useInternalPhoneForC2C; // Использовать внутренний номер телефона для Click2Call, иначе - внешний
    private String personnelNumber; // Табельный номер
    private String subdivision; // Подразделение
    private Set<String> roles = new HashSet<>();
    private Set<String> creditTypes = new HashSet<>(); // Типы кредитов, обслуживаемые сотрудником
    private List<AbsencePeriod> absence = new ArrayList<>(); // Периоды недоступности сотрудника

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSberPdi() {
        return sberPdi;
    }

    public void setSberPdi(String sberPdi) {
        this.sberPdi = sberPdi;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    public String getWorkingDayStartTime() {
        return workingDayStartTime;
    }

    public void setWorkingDayStartTime(String workingDayStartTime) {
        this.workingDayStartTime = workingDayStartTime;
    }

    public String getWorkingDayEndTime() {
        return workingDayEndTime;
    }

    public void setWorkingDayEndTime(String workingDayEndTime) {
        this.workingDayEndTime = workingDayEndTime;
    }

    public BigDecimal getSumLimitFrom() {
        return sumLimitFrom;
    }

    public void setSumLimitFrom(BigDecimal sumLimitFrom) {
        this.sumLimitFrom = sumLimitFrom;
    }

    public BigDecimal getSumLimitTo() {
        return sumLimitTo;
    }

    public void setSumLimitTo(BigDecimal sumLimitTo) {
        this.sumLimitTo = sumLimitTo;
    }

    public String getExternalPhone() {
        return externalPhone;
    }

    public void setExternalPhone(String externalPhone) {
        this.externalPhone = externalPhone;
    }

    public String getInternalPhone() {
        return internalPhone;
    }

    public void setInternalPhone(String internalPhone) {
        this.internalPhone = internalPhone;
    }

    public boolean isUseInternalPhoneForC2C() {
        return useInternalPhoneForC2C;
    }

    public void setUseInternalPhoneForC2C(boolean useInternalPhoneForC2C) {
        this.useInternalPhoneForC2C = useInternalPhoneForC2C;
    }

    public String getPersonnelNumber() {
        return personnelNumber;
    }

    public void setPersonnelNumber(String personnelNumber) {
        this.personnelNumber = personnelNumber;
    }

    public String getSubdivision() {
        return subdivision;
    }

    public void setSubdivision(String subdivision) {
        this.subdivision = subdivision;
    }

    public Set<String> getRoles() {
        return roles;
    }

    public void setRoles(Set<String> roles) {
        this.roles = roles;
    }

    public Set<String> getCreditTypes() {
        return creditTypes;
    }

    public void setCreditTypes(Set<String> creditTypes) {
        this.creditTypes = creditTypes;
    }

    public List<AbsencePeriod> getAbsence() {
        return absence;
    }

    public void setAbsence(List<AbsencePeriod> absence) {
        this.absence = absence;
    }

    @Override
    public final boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;

        User user = (User) o;

        return getSberPdi() != null ? getSberPdi().equals(user.getSberPdi()) : user.getSberPdi() == null;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        String res = lastName + " ";
        if (firstName != null && firstName.length() > 0) {
            res += firstName.substring(0, 1).toUpperCase() + ".";
        }
        if (middleName != null && middleName.length() > 0) {
            res += middleName.substring(0, 1).toUpperCase() + ".";
        }
        return res;
    }

    private String getSumLimitFromAsString() {
        return Optional.ofNullable(sumLimitFrom)
                .map(s -> s.stripTrailingZeros().toPlainString())
                .orElse(null);
    }

    private String getSumLimitToAsString() {
        return Optional.ofNullable(sumLimitTo)
                .map(s -> s.stripTrailingZeros().toPlainString())
                .orElse(null);
    }

    public boolean identical(User user) {
        if (this == user) return true;
        return isDeleted() == user.isDeleted() &&
                Objects.equals(getId(), user.getId()) &&
                Objects.equals(getPersonnelNumber(), user.getPersonnelNumber()) &&
                Objects.equals(getFirstName(), user.getFirstName()) &&
                Objects.equals(getLastName(), user.getLastName()) &&
                Objects.equals(getMiddleName(), user.getMiddleName()) &&
                Objects.equals(getEmail(), user.getEmail()) &&
                Objects.equals(getSberPdi(), user.getSberPdi()) &&
                Objects.equals(getTimeZone(), user.getTimeZone()) &&
                Objects.equals(getWorkingDayStartTime(), user.getWorkingDayStartTime()) &&
                Objects.equals(getWorkingDayEndTime(), user.getWorkingDayEndTime()) &&
                Objects.equals(getSumLimitFromAsString(), user.getSumLimitFromAsString()) &&
                Objects.equals(getSumLimitToAsString(), user.getSumLimitToAsString()) &&
                Objects.equals(getExternalPhone(), user.getExternalPhone()) &&
                Objects.equals(getInternalPhone(), user.getInternalPhone()) &&
                isUseInternalPhoneForC2C() == user.isUseInternalPhoneForC2C() &&
                Objects.equals(getSubdivision(), user.getSubdivision()) &&
                getRoles().containsAll(user.getRoles()) &&
                user.getRoles().containsAll(getRoles()) &&
                getCreditTypes().containsAll(user.getCreditTypes()) &&
                user.getCreditTypes().containsAll(getCreditTypes()) &&
                getAbsence().containsAll(user.getAbsence()) &&
                user.getAbsence().containsAll(getAbsence());
    }
}
