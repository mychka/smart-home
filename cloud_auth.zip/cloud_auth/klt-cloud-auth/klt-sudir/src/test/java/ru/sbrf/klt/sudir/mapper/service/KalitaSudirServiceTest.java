package ru.sbrf.klt.sudir.mapper.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import ru.sber.sudir.scim.agent.api.model.SudirUser;
import ru.sbrf.klt.sudir.AbstractTest;
import ru.sbrf.klt.sudir.kalita.mapper.GenericAccountMapper;
import ru.sbrf.klt.sudir.kalita.service.KalitaSudirService;
import ru.sbrf.klt.sudir.kalita.xml.*;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

class KalitaSudirServiceTest extends AbstractTest {

    private static final KalitaSudirService service = new KalitaSudirService();
    private static final Jaxb2Marshaller marshaller = new Jaxb2Marshaller();

    private WebServiceTemplate webServiceTemplate;
    private final GenericAccountMapper mapper = new GenericAccountMapper();

    @BeforeEach
    public void setup() {
        webServiceTemplate = Mockito.mock(WebServiceTemplate.class);
        service.setDefaultUri("uri");
        service.setMarshaller(marshaller);
        service.setUnmarshaller(marshaller);
        service.setWebServiceTemplate(webServiceTemplate);
    }

    @Test
    void testGetUserById() {
        SudirUser user = getUser();
        GenericAccountInfo genAcc = mapper.fromEntity(user);
        GetAccountListByIdResponse response = new GetAccountListByIdResponse();
        response.getGetAccountListByIdReturn().add(genAcc);
        Mockito.doReturn(response).when(webServiceTemplate).marshalSendAndReceive(Mockito.any());
        assertEquals(user, service.getUserById("USER"));
    }

    @Test
    void testModifyUser() {
        SudirUser user = getUser();
        Mockito.doReturn(new ModifyAccountResponse()).when(webServiceTemplate).marshalSendAndReceive(Mockito.any());
        service.modifyUser(user);
        verify(webServiceTemplate, times(1)).marshalSendAndReceive(Mockito.any());
    }

    @Test
    void testCreateUser() {
        SudirUser user = getUser();
        Mockito.doReturn(new CreateAccountResponse()).when(webServiceTemplate).marshalSendAndReceive(Mockito.any());
        service.createUser(user);
        ArgumentCaptor<CreateAccount> argumentCaptor = ArgumentCaptor.forClass(CreateAccount.class);
        verify(webServiceTemplate, times(1)).marshalSendAndReceive(Mockito.any());
    }

    @Test
    void testMarkSuspend() {
        Mockito.doReturn(new SuspendAccountResponse()).when(webServiceTemplate).marshalSendAndReceive(Mockito.any());
        service.markSuspend("USER");
        ArgumentCaptor<SuspendAccount> argumentCaptor = ArgumentCaptor.forClass(SuspendAccount.class);
        verify(webServiceTemplate, times(1)).marshalSendAndReceive(Mockito.any());
    }

    public SudirUser getUser() {
        SudirUser user = new SudirUser();
        user.setId("USER");
        user.setUserName("USER");
        user.setGivenName("Игорь");
        user.setMiddleName("Николаевич");
        user.setFamilyName("Иванович");
        user.setDisplayName("Иванович");
        user.setEmployeeNumber("123");
        user.setIntEmail("test@mail");
        user.setTitle("test@mail");
        user.setActive(true);
        List<String> roles = new ArrayList<>();
        roles.add("1");
        user.setRoles(roles);
        List<String> foses = new ArrayList<>();
        foses.add("99");
        user.setFosNodes(foses);
        return user;
    }
}