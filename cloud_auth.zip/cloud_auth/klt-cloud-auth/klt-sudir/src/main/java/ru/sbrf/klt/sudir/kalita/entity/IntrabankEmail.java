package ru.sbrf.klt.sudir.kalita.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "INTRABANK_EMAIL")
public class IntrabankEmail {

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "INTRABANK_EMAIL_SEQ")
    @SequenceGenerator(name = "INTRABANK_EMAIL_SEQ", sequenceName = "INTRABANK_EMAIL_SEQ", allocationSize = 1)
    private long id;

    @Column(name = "INTRABANK_EMAIL")
    private String intrabankEmail;

    @Column(name = "OUTER_EMAIL")
    private String outerEmail;

    public long getId() {
        return id;
    }

    public String getIntrabankEmail() {
        return intrabankEmail;
    }

    public String getOuterEmail() {
        return outerEmail;
    }

}