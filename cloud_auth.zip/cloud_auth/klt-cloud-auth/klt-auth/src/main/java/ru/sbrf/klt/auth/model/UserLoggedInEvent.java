package ru.sbrf.klt.auth.model;

import java.time.LocalDateTime;

public class UserLoggedInEvent extends UserEvent {
    public static final String TYPE = "USER_LOGGED_IN";

    public UserLoggedInEvent() {
        setType(TYPE);
        setTimestamp(LocalDateTime.now());
    }

    public UserLoggedInEvent(User user) {
        this();
        setUser(user);
    }
}
