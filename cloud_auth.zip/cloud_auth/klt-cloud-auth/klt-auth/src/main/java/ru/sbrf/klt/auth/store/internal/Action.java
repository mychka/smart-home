package ru.sbrf.klt.auth.store.internal;

public enum Action {

    CREATE, IGNORE, UPDATE;
}
