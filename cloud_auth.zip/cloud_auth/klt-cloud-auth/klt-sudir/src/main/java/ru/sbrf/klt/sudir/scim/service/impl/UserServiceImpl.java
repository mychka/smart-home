package ru.sbrf.klt.sudir.scim.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.sber.sudir.scim.agent.api.exception.ScimException;
import ru.sber.sudir.scim.agent.api.model.SudirUser;
import ru.sber.sudir.scim.agent.api.service.UserService;
import ru.sbrf.klt.sudir.kalita.repository.KalitaUserRepository;
import ru.sbrf.klt.sudir.kalita.service.KalitaSudirService;
import ru.sbrf.klt.sudir.scim.mapper.KalitaSudirMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Имплементация сервиса пользователей UserService
 */

@Slf4j
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
    private final ObjectMapper objectMapper;
    private final KalitaUserRepository userRepository;
    private final KalitaSudirMapper sudirMapper;
    private final KalitaSudirService kalitaSudirService;

    /**
     * Получить пользователя по логину
     *
     * @param userName - логин
     * @return SudirUser
     * @throws ScimException
     */
    @Override
    public SudirUser getByUserName(String userName) throws ScimException {
        return kalitaSudirService.getUserById(userName);
    }

    /**
     * Сохранить в базе пользователя
     *
     * @param sudirUser - пользователь
     * @return SudirUser - сохраненные данные, которые могут отличаться из-за поддержки обязательных полей
     * и сохранение значений у неизменяемых
     * @throws ScimException
     */
    @Override
    @Transactional
    public SudirUser save(SudirUser sudirUser) throws ScimException {
        printJsonToLog("Пришли из СУДИР данные пользователя:{}", sudirUser);
        if (sudirUser.getId() == null) {
            String id = sudirUser.getUserName();
            sudirUser.setId(id);
            kalitaSudirService.createUser(sudirUser);
        } else {
            kalitaSudirService.modifyUser(sudirUser);
        }
        if (!sudirUser.getActive()) {
            kalitaSudirService.markSuspend(sudirUser.getId());
        }
        SudirUser userReq = kalitaSudirService.getUserById(sudirUser.getUserName());
        printJsonToLog("Отправили в СУДИР данные пользователя:{}", userReq);
        return userReq;

    }

    /**
     * Удаление - удаляем все роли и пользователю выдается роль Удаленный пользователь
     *
     * @param id - login
     * @throws ScimException
     */
    @Override
    public void markDeleted(String id) throws ScimException {
        SudirUser user = kalitaSudirService.getUserById(id);
        user.setRoles(new ArrayList<>());
        kalitaSudirService.modifyUser(user);
    }

    /**
     * Получить пользователя по ID, ID=Username
     *
     * @param id - идентификатор пользователя
     * @return - SudirUser из базы , null  если не найден
     * @throws ScimException
     */
    @Override
    public SudirUser getById(String id) throws ScimException {
        SudirUser user = kalitaSudirService.getUserById(id);
        printJsonToLog("Отправили в СУДИР данные пользователя:{}", user);
        return user;

    }

    /**
     * Получить страницу пользователей
     *
     * @param start - стартовая позиция
     * @param count - количество пользователей на странице
     * @return List<SudirUser> - страница пользователей
     */
    @Override
    @Transactional
    public List<SudirUser> getPage(int start, int count) {
        log.debug("getPage: start {} count {}", start, count);
        return userRepository.getUsersPage(start - 1, count)
                             .map(sudirMapper::of)
                             .collect(Collectors.toList());
    }

    /**
     * Получить количество активных пользователей в таблице
     *
     * @return -количество пользователей
     * @throws ScimException
     */
    @Override
    public int getCount() throws ScimException {
        return userRepository.getUserCount();
    }

    /**
     * Печать сообщения и объекта в лог, объект в лог записывается   виде json структуры
     *
     * @param message - сообщение
     * @param object  - объект
     */
    protected void printJsonToLog(String message, Object object) {
        try {
            log.debug(message,
                      objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(object));

        } catch (JsonProcessingException e) {
            String errinfo = String.format("Неожиданная ошибка преобразования в json %s", e.getMessage());
            log.error(errinfo, e);
        }
    }

}