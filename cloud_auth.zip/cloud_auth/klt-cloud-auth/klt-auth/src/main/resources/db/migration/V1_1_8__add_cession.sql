insert into user_main_menu select 'cession','/cession', 'Цессия'
where not exists (select id from user_main_menu where id ='cession');


insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Бизнес-аналитик', '/klt-auth/mainmenu', 'cession', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Бизнес-аналитик' and v1 = '/klt-auth/mainmenu' and v2 = 'cession' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Администратор', '/klt-auth/mainmenu', 'cession', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Администратор' and v1 = '/klt-auth/mainmenu' and v2 = 'cession' and v3 = 'read');