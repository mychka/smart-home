package ru.sbrf.klt.sudir.kalita.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "DICT_REG_BANK_CODE")
@Cacheable
public class RegionalBankCodeDict {

    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "CODE")
    private String code;

    @Basic
    @Column(name = "DESCRIPTION")
    private String description;

    @Basic
    @Column(name = "SHORT_DESCRIPTION")
    private String shortDescription;

    @Basic
    @Column(name = "IS_DEFAULT")
    private Boolean isDefault = false;

    @Basic
    @Column(name = "SORT_ORDER")
    private Long sortOrder;

    @Basic
    @Column(name = "IS_ENABLED")
    private Boolean isEnabled = true;

    @Basic
    @Column(name = "IS_DELETED")
    private Boolean isDeleted = false;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public Long getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Long order) {
        this.sortOrder = order;
    }

    @PrePersist
    private void setSortOrder() {
        if (sortOrder == null) {
            sortOrder = 1L;
        }
    }

    public Boolean getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(Boolean isEnabled) {
        this.isEnabled = isEnabled;
    }

    public Boolean getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(Boolean isDefault) {
        this.isDefault = isDefault;
    }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

}