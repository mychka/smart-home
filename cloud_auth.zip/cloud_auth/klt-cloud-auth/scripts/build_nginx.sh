echo build container

podman build -f ../nginx/Dockerfile -t nginx:1  --tls-verify=false

read -p "Press enter to continue"