package ru.sbrf.klt.sudir;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * Spring - приложение. Интеграция АС Калита и Судир посредством интерфейса SCIM 2.0
 */
@SpringBootApplication
@EnableJpaRepositories
public class ScimApplication {

    public static void main(String[] args) {
        SpringApplication.run(ScimApplication.class, args);
    }
}