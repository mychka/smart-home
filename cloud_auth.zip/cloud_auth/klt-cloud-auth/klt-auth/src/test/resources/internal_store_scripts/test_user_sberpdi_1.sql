INSERT INTO user_data (sber_pdi, id, personnel_number, last_name, first_name, middle_name, email, time_zone, working_day_start_time, working_day_end_time, sum_limit_from, sum_limit_to, external_phone, internal_phone, use_internal_phone_for_c2c, subdivision_code, is_deleted)
VALUES ('sberpdi_1', 'test_user', 'Settle_BA', 'Бизнес', 'Аналитик', 'Аналитикович', 'AABiznes@omega.sbrf.ru', 'UTC+03:00', null, null, null, null, null, null, false, null, false);
INSERT INTO user_role VALUES ('sberpdi_1', 'test_role_1');
INSERT INTO user_role VALUES ('sberpdi_1', 'test_role_2');
INSERT INTO user_role VALUES ('sberpdi_1', 'test_role_3');
INSERT INTO user_credit_type VALUES ('sberpdi_1', '1');
INSERT INTO casbin_rule (ptype, v0, v1, v2) VALUES('g', 'sberpdi_1', 'test_role_1', '*');
INSERT INTO casbin_rule (ptype, v0, v1, v2) VALUES('g', 'sberpdi_1', 'test_role_2', '*');
INSERT INTO casbin_rule (ptype, v0, v1, v2) VALUES('g', 'sberpdi_1', 'test_role_3', '*');
