-- init_kalita_db.sql is executed by default only for embedded databases

create table ACT_ID_USER
(
    ID_ varchar(255) not null primary key,
    LAST_ varchar(255),
    FIRST_ varchar(255),
    MIDDLE_NAME_ varchar(255),
    SBER_PDI varchar(255),
    EMAIL_ varchar(255),
    IS_DELETED boolean default 0,
    ABSENCE_START_DATE timestamp,
    ABSENCE_END_DATE timestamp,
    PERSONNEL_NUMBER varchar(30),
    SUBDIVISION_ID number(19),
    INTRABANK_EMAIL_ID number(19)
);

create table ROLE
(
    ID long primary key,
    NAME varchar(255),
    IS_DELETED boolean default 0
);

create table V_USER_ROLES
(
    ID_ varchar(255) not null,
    R_ID long not null
);

create table DICT_TIMEZONE
(
    ID   number(19) not null primary key,
    CODE varchar(50) not null
);

create table USER_SETTLEMENT
(
    USER_ID varchar(255) not null,
    TIMEZONE_ID number(19),
    WORKING_DAY_START_TIME varchar(10),
    WORKING_DAY_END_TIME varchar(10),
    SUM_LIMIT_FROM number(19,2),
    SUM_LIMIT_TO number(19,2)
);

create table USER_PROCESSING_PATH
(
    USER_ID varchar(255) not null,
    PROCESSING_PATH_ID number(19) not null
);

create table DICT_PROCESSING_PATH
(
    ID number(19) not null primary key,
    CODE varchar(100) not null,
    DESCRIPTION varchar(500),
    SHORT_DESCRIPTION varchar(500)
);

create table INTRABANK_PHONE_NUMBER
(
    ID number(19) not null primary key,
    USER_ID varchar(64) not null,
    EXTERNAL_NUMBER varchar(50),
    INTERNAL_NUMBER varchar(50),
    USE_INTERNAL_NUMBER_C2C number(1)
);

create table DICT_SUBDIVISION
(
    ID number(19) not null primary key,
    CODE varchar(100) not null,
    DESCRIPTION varchar(500),
    SHORT_DESCRIPTION varchar(500)
);

create table INTRABANK_EMAIL
(
    ID number(19) not null primary key,
    INTRABANK_EMAIL varchar(500)
);

insert into INTRABANK_EMAIL(ID, INTRABANK_EMAIL) values(1, 'admin@admin.ru');

insert into ACT_ID_USER(ID_, SBER_PDI, EMAIL_, LAST_, FIRST_, MIDDLE_NAME_, ABSENCE_START_DATE, ABSENCE_END_DATE, INTRABANK_EMAIL_ID)
values('admin', '000001', 'admin@klt', 'Калита', 'Иван', 'Данилович',
       parsedatetime('17-02-2023 09:00:00', 'dd-MM-yyyy hh:mm:ss'), parsedatetime('21-02-2023 09:00:00', 'dd-MM-yyyy hh:mm:ss'), 1);
insert into ROLE(ID, NAME) values (1, 'SUPERUSER');
insert into ROLE(ID, NAME) values (2, 'USER');
insert into V_USER_ROLES values ('admin',1);
insert into V_USER_ROLES values ('admin',2);

insert into ACT_ID_USER(ID_, SBER_PDI, EMAIL_, LAST_, FIRST_, MIDDLE_NAME_, ABSENCE_START_DATE, ABSENCE_END_DATE)
values('user', '000002', 'user@klt', 'Федоров', 'Федор', 'Федорович',
       parsedatetime('18-02-2023 09:00:00', 'dd-MM-yyyy hh:mm:ss'), parsedatetime('22-02-2023 09:00:00', 'dd-MM-yyyy hh:mm:ss'));
insert into V_USER_ROLES values ('user',2);

insert into ROLE(ID, NAME) values (3, 'Ассистент сотрудника урегулирования ФЛ');
insert into ACT_ID_USER(ID_, SBER_PDI, EMAIL_, LAST_, FIRST_, MIDDLE_NAME_, ABSENCE_START_DATE, ABSENCE_END_DATE)
values('test', '000003', 'user@klt', 'Сидоров', 'Федор', 'Петрович',
       parsedatetime('15-02-2023 09:00:00', 'dd-MM-yyyy hh:mm:ss'), parsedatetime('24-02-2023 09:00:00', 'dd-MM-yyyy hh:mm:ss'));
insert into V_USER_ROLES values ('test',3);

insert into DICT_TIMEZONE(ID, CODE) values(1, 'UTC+02:00');
insert into DICT_TIMEZONE(ID, CODE) values(2, 'UTC+03:00');
insert into DICT_TIMEZONE(ID, CODE) values(3, 'UTC+12:00');

insert into DICT_PROCESSING_PATH(ID, CODE, DESCRIPTION, SHORT_DESCRIPTION) values (1,1,'Кредитная карта', 'Кредитная карта');
insert into DICT_PROCESSING_PATH(ID, CODE, DESCRIPTION, SHORT_DESCRIPTION) values (2,2,'Потребительский кредит (кредит без обеспечения)', 'Потребкредит без обеспечения');
insert into DICT_PROCESSING_PATH(ID, CODE, DESCRIPTION, SHORT_DESCRIPTION) values (3,3,'Ипотечный кредит', 'Ипотека');