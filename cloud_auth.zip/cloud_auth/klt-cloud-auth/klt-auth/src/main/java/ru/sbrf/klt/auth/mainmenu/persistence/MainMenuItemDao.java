package ru.sbrf.klt.auth.mainmenu.persistence;

import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.DataClassRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.util.List;

@Slf4j
@Component
public class MainMenuItemDao {

    private final JdbcTemplate jdbc;

    public MainMenuItemDao(DataSource dataSource) {
        jdbc = new JdbcTemplate(dataSource);
    }

    public List<MainMenuItem> getAllMenuItems() {
        log.debug("Querying for all menu items");
        String getUserSql = """
                select id, path, display_name 
                from user_main_menu
                """;
        List<MainMenuItem> mainMenuItems;
        mainMenuItems = jdbc.query(getUserSql, new DataClassRowMapper<>(MainMenuItem.class));

        return mainMenuItems;
    }

    public void addItem(MainMenuItem item) {
        String insertSql = "insert into user_main_menu values(?,?,?)";
        jdbc.update(insertSql, item.id(), item.path(), item.displayName());
    }
}
