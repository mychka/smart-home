insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Ассистент Инспектора СИП', '/klt-auth/mainmenu', 'sip-ippz', 'read'
    where not exists (select id from casbin_rule where ptype = 'p' and v0 = 'Ассистент Инспектора СИП' and v1 = '/klt-auth/mainmenu' and v2 = 'sip-ippz' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Сотрудник ПУПЗ', '/klt-auth/mainmenu', 'special-cases', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник ПУПЗ' and v1 = '/klt-auth/mainmenu' and v2 = 'special-cases' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Руководитель ПУПЗ', '/klt-auth/mainmenu', 'special-cases', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Руководитель ПУПЗ' and v1 = '/klt-auth/mainmenu' and v2 = 'special-cases' and v3 = 'read');