package ru.sbrf.klt.auth.crypto;

import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import javax.crypto.EncryptedPrivateKeyInfo;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class RSAKeyUtil {

    private RSAKeyUtil() {
    }

    private static String getKey(String filename) throws IOException {
        // Read key from file or classpath resource
        ResourceLoader resourceLoader = new PathMatchingResourcePatternResolver();
        StringBuilder strKeyPEM = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(resourceLoader.getResource(filename).getInputStream()))) {
            String line;
            while ((line = br.readLine()) != null) {
                strKeyPEM.append(line).append("\n");
            }
        }

        return strKeyPEM.toString();
    }

    public static RSAPrivateKey getEncryptedPrivateKey(String filename, String password) throws IOException, GeneralSecurityException {
        String privateKeyPEM = getKey(filename);
        return getEncryptedPrivateKeyFromString(privateKeyPEM, password);
    }

    public static RSAPrivateKey getEncryptedPrivateKeyFromString(String key, String password) throws IOException, GeneralSecurityException {
        String privateKeyPEM = key;
        privateKeyPEM = privateKeyPEM.replace("-----BEGIN ENCRYPTED PRIVATE KEY-----\n", "");
        privateKeyPEM = privateKeyPEM.replace("-----END ENCRYPTED PRIVATE KEY-----", "");
        privateKeyPEM = privateKeyPEM.replaceAll(System.getProperty("line.separator"), "");
        privateKeyPEM = privateKeyPEM.replaceAll("\\n", "");
        byte[] encoded = Base64.getDecoder().decode(privateKeyPEM);

        EncryptedPrivateKeyInfo pkInfo = new EncryptedPrivateKeyInfo(encoded);
        PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray()); // password
        SecretKeyFactory pbeKeyFactory = SecretKeyFactory.getInstance(pkInfo.getAlgName());
        PKCS8EncodedKeySpec encodedKeySpec = pkInfo.getKeySpec(pbeKeyFactory.generateSecret(keySpec));

        KeyFactory kf = KeyFactory.getInstance("RSA");
        return (RSAPrivateKey) kf.generatePrivate(encodedKeySpec);
    }

    public static RSAPublicKey getPublicKey(String filename) throws IOException, GeneralSecurityException {
        String publicKeyPEM = getKey(filename);
        return getPublicKeyFromString(publicKeyPEM);
    }

    public static RSAPublicKey getPublicKeyFromString(String key) throws GeneralSecurityException {
        String publicKeyPEM = key;
        publicKeyPEM = publicKeyPEM.replace("-----BEGIN PUBLIC KEY-----\n", "");
        publicKeyPEM = publicKeyPEM.replace("-----END PUBLIC KEY-----", "");
        publicKeyPEM = publicKeyPEM.replaceAll(System.getProperty("line.separator"), "");
        publicKeyPEM = publicKeyPEM.replaceAll("\\n", "");
        byte[] encoded = Base64.getDecoder().decode(publicKeyPEM);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return (RSAPublicKey) kf.generatePublic(new X509EncodedKeySpec(encoded));
    }

    public static String sign(PrivateKey privateKey, String message) throws NoSuchAlgorithmException, InvalidKeyException, SignatureException {
        Signature sign = Signature.getInstance("SHA-512");
        sign.initSign(privateKey);
        sign.update(message.getBytes(StandardCharsets.UTF_8));
        return new String(Base64.getDecoder().decode(sign.sign()), StandardCharsets.UTF_8);
    }


    public static boolean verify(PublicKey publicKey, String message, String signature) throws SignatureException, NoSuchAlgorithmException, InvalidKeyException {
        Signature sign = Signature.getInstance("SHA-512");
        sign.initVerify(publicKey);
        sign.update(message.getBytes(StandardCharsets.UTF_8));
        return sign.verify(Base64.getDecoder().decode(signature.getBytes(StandardCharsets.UTF_8)));
    }

}
