package ru.sbrf.klt.auth.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Slf4j
@Component
@RefreshScope
public class ConfigService {

    @Value("${app.config}")
    private String config;

    public String getConfig() {
        log.debug("App config :{} ", config);
        return config;
    }

    @EventListener(RefreshScopeRefreshedEvent.class)
    public void onRefresh(RefreshScopeRefreshedEvent event) throws IOException {
        log.info("Configuration update from Cloud config server");
    }
}