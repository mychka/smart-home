insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Сотрудник ЦЗК+VIP', '/klt-auth/mainmenu', 'settlement', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Сотрудник ЦЗК+VIP' and v1 = '/klt-auth/mainmenu' and v2 = 'settlement' and v3 = 'read');