create table user_main_menu(
                        id    varchar(32) not null primary key,
                        path  varchar(32) not null,
                        display_name varchar(100) not null,
                        constraint uniq_user_main_menu unique(path)
);


insert into user_main_menu values('settlement','/settlement', 'Урегулирование');
insert into user_main_menu values('sip','/sip', 'СИП');
