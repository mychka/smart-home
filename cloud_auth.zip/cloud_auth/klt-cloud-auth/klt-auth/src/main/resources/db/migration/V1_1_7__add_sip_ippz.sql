insert into user_main_menu select 'sip-ippz','/sip-ippz', 'СИП Платежи'
where not exists (select id from user_main_menu where id ='sip-ippz');


insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Бизнес-аналитик', '/klt-auth/mainmenu', 'sip-ippz', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Бизнес-аналитик' and v1 = '/klt-auth/mainmenu' and v2 = 'sip-ippz' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Администратор', '/klt-auth/mainmenu', 'sip-ippz', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Администратор' and v1 = '/klt-auth/mainmenu' and v2 = 'sip-ippz' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Инспектор ПСИП-Пилот', '/klt-auth/mainmenu', 'sip-ippz', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Инспектор ПСИП-Пилот' and v1 = '/klt-auth/mainmenu' and v2 = 'sip-ippz' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Инспектор ОСИП - пилот ПЦП', '/klt-auth/mainmenu', 'sip-ippz', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Инспектор ОСИП - пилот ПЦП' and v1 = '/klt-auth/mainmenu' and v2 = 'sip-ippz' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Руководитель ОСИП - пилот ПЦП', '/klt-auth/mainmenu', 'sip-ippz', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Руководитель ОСИП - пилот ПЦП' and v1 = '/klt-auth/mainmenu' and v2 = 'sip-ippz' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Ассистент Инспектора СИП', '/klt-auth/mainmenu', 'sip-ippz', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Ассистент Инспектора СИП' and v1 = '/klt-auth/mainmenu' and v2 = 'sip-ippz' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Региональный менеджер ОСИП', '/klt-auth/mainmenu', 'sip-ippz', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Региональный менеджер ОСИП' and v1 = '/klt-auth/mainmenu' and v2 = 'sip-ippz' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Руководитель ПСИП-Пилот', '/klt-auth/mainmenu', 'sip-ippz', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Руководитель ПСИП-Пилот' and v1 = '/klt-auth/mainmenu' and v2 = 'sip-ippz' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Аудитор', '/klt-auth/mainmenu', 'sip-ippz', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Аудитор' and v1 = '/klt-auth/mainmenu' and v2 = 'sip-ippz' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Инспектор ОСИП', '/klt-auth/mainmenu', 'sip-ippz', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Инспектор ОСИП' and v1 = '/klt-auth/mainmenu' and v2 = 'sip-ippz' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Руководитель ОСИП', '/klt-auth/mainmenu', 'sip-ippz', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Руководитель ОСИП' and v1 = '/klt-auth/mainmenu' and v2 = 'sip-ippz' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Региональный менеджер ПСИП-Пилот', '/klt-auth/mainmenu', 'sip-ippz', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Региональный менеджер ПСИП-Пилот' and v1 = '/klt-auth/mainmenu' and v2 = 'sip-ippz' and v3 = 'read');