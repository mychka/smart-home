package ru.sbrf.klt.auth.store.internal;

import lombok.extern.slf4j.Slf4j;
import org.casbin.jcasbin.main.Enforcer;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.sbrf.klt.auth.casbin.CasbinAuthDomains;
import ru.sbrf.klt.auth.model.AbsencePeriod;
import ru.sbrf.klt.auth.model.User;

import javax.sql.DataSource;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.*;

import static java.util.Objects.isNull;
import static org.apache.commons.lang3.StringUtils.trimToNull;
import static ru.sbrf.klt.auth.store.internal.Action.*;

@Slf4j
@Component
public class InternalUserStoreDao {

    private final Enforcer enforcer;

    private final JdbcTemplate jdbc;

    public InternalUserStoreDao(DataSource dataSource, Enforcer enforcer) {
        jdbc = new JdbcTemplate(dataSource);
        this.enforcer = enforcer;
    }

    public User findBySberPdi(String sberPdi) {
        log.debug("Find user by sber pdi = {} in internal store", sberPdi);
        String getUserSql = """
                select id, last_name, first_name, middle_name, sber_pdi, email, time_zone,
                working_day_start_time, working_day_end_time, sum_limit_from, sum_limit_to, is_deleted, 
                external_phone, internal_phone, use_internal_phone_for_c2c, personnel_number, subdivision_code
                from user_data 
                where sber_pdi = ?
                """;
        User user;
        try {
            user = jdbc.queryForObject(getUserSql, (rs, rowNum) -> {
                User u = new User();
                u.setId(rs.getString("id"));
                u.setLastName(rs.getString("last_name"));
                u.setFirstName(rs.getString("first_name"));
                u.setMiddleName(rs.getString("middle_name"));
                u.setSberPdi(rs.getString("sber_pdi"));
                u.setEmail(rs.getString("email"));
                u.setTimeZone(rs.getString("time_zone"));
                u.setWorkingDayStartTime(rs.getString("working_day_start_time"));
                u.setWorkingDayEndTime(rs.getString("working_day_end_time"));
                u.setSumLimitFrom(rs.getBigDecimal("sum_limit_from"));
                u.setSumLimitTo(rs.getBigDecimal("sum_limit_to"));
                u.setExternalPhone(rs.getString("external_phone"));
                u.setInternalPhone(rs.getString("internal_phone"));
                u.setUseInternalPhoneForC2C(rs.getBoolean("use_internal_phone_for_c2c"));
                u.setDeleted(rs.getBoolean("is_deleted"));
                u.setPersonnelNumber(rs.getString("personnel_number"));
                u.setSubdivision(rs.getString("subdivision_code"));
                return u;
            }, trimToNull(sberPdi));
        } catch (IncorrectResultSizeDataAccessException ex) {
            log.error("Пользователь по pdi: {} не найден, message:{} ", sberPdi, ex.getMessage());
            return null;
        }
        // getting roles;
        String getUserRolesSql = """
                select r.role, u.id
                from user_data u
                join user_role r on r.sber_pdi = u.sber_pdi
                where u.sber_pdi = ?
                """;
        jdbc.query(getUserRolesSql,
                ps -> ps.setString(1, trimToNull(sberPdi)),
                rs -> {
                    user.getRoles().add(rs.getString("role"));
                });
        // Get credit types
        String getCreditTypesSql = """
                select c.credit_type_code, u.id
                from user_data u
                join user_credit_type c on c.sber_pdi = u.sber_pdi
                where u.sber_pdi = ?
                """;
        jdbc.query(getCreditTypesSql,
                ps -> ps.setString(1, trimToNull(sberPdi)),
                rs -> {
                    user.getCreditTypes().add(rs.getString("credit_type_code"));
                });
        // Get absence
        String getUserAbsenceSql = """
                select a.start_date, a.end_date, u.id
                from user_data u
                join user_absence a on a.sber_pdi = u.sber_pdi
                where u.sber_pdi = ?
                """;
        jdbc.query(getUserAbsenceSql,
                ps -> ps.setString(1, trimToNull(sberPdi)),
                rs -> {
                    LocalDate start = Optional.ofNullable(rs.getDate("start_date"))
                            .map(Date::toLocalDate).orElse(null);
                    LocalDate end = Optional.ofNullable(rs.getDate("end_date"))
                            .map(Date::toLocalDate).orElse(null);
                    if (start != null || end != null) {
                        user.getAbsence().add(new AbsencePeriod(start, end));
                    }
                });
        return user;
    }

    @Transactional
    public Action createOrUpdateUser(User user) {
        User findUser = findBySberPdi(user.getSberPdi());
        if (isNull(findUser)) {
            create(user);
            saveCasbinGroups(user);
            return CREATE;
        } else if (user.identical(findUser)) { // Здесь может быть только 1 пользователь в списке, так как мы искали по первичному ключу
            return IGNORE;
        } else {
            update(user);
            mergeCasbinGroups(user);
            return UPDATE;
        }
    }

    private void create(User user) {
        log.info("Create user {} in internal store", user);
        String createUserSql = "insert into user_data (id, last_name, first_name, middle_name, sber_pdi, " +
                "email, is_deleted, time_zone, working_day_start_time, working_day_end_time, sum_limit_from, sum_limit_to, " +
                "external_phone, internal_phone, use_internal_phone_for_c2c, personnel_number, subdivision_code) " +
                "values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        jdbc.update(createUserSql,
                ps -> {
                    ps.setString(1, user.getId());
                    ps.setString(2, user.getLastName());
                    ps.setString(3, user.getFirstName());
                    ps.setString(4, user.getMiddleName());
                    ps.setString(5, user.getSberPdi());
                    ps.setString(6, user.getEmail());
                    ps.setBoolean(7, user.isDeleted());
                    ps.setString(8, user.getTimeZone());
                    ps.setString(9, user.getWorkingDayStartTime());
                    ps.setString(10, user.getWorkingDayEndTime());
                    ps.setBigDecimal(11, user.getSumLimitFrom());
                    ps.setBigDecimal(12, user.getSumLimitTo());
                    ps.setString(13, user.getExternalPhone());
                    ps.setString(14, user.getInternalPhone());
                    ps.setBoolean(15, user.isUseInternalPhoneForC2C());
                    ps.setString(16, user.getPersonnelNumber());
                    ps.setString(17, user.getSubdivision());
                });

        saveRoles(user.getSberPdi(), new ArrayList<>(user.getRoles()));
        saveCreditTypes(user.getSberPdi(), new ArrayList<>(user.getCreditTypes()));
        saveAbsence(user.getSberPdi(), user.getAbsence());
    }

    private void update(User user) {
        log.info("Update user {} in internal store", user);
        String createUserSql = "update user_data set last_name = ?, " +
                "first_name = ?, " +
                "middle_name = ?, " +
                "id = ?, " +
                "email = ?, " +
                "is_deleted = ?, " +
                "time_zone = ?, " +
                "working_day_start_time = ?, " +
                "working_day_end_time = ?, " +
                "sum_limit_from = ?, " +
                "sum_limit_to = ?, " +
                "external_phone = ?, " +
                "internal_phone = ?, " +
                "use_internal_phone_for_c2c = ?, " +
                "personnel_number = ?, " +
                "subdivision_code = ? " +
                "where sber_pdi = ?";
        jdbc.update(createUserSql,
                ps -> {
                    ps.setString(1, user.getLastName());
                    ps.setString(2, user.getFirstName());
                    ps.setString(3, user.getMiddleName());
                    ps.setString(4, user.getId());
                    ps.setString(5, user.getEmail());
                    ps.setBoolean(6, user.isDeleted());
                    ps.setString(7, user.getTimeZone());
                    ps.setString(8, user.getWorkingDayStartTime());
                    ps.setString(9, user.getWorkingDayEndTime());
                    ps.setBigDecimal(10, user.getSumLimitFrom());
                    ps.setBigDecimal(11, user.getSumLimitTo());
                    ps.setString(12, user.getExternalPhone());
                    ps.setString(13, user.getInternalPhone());
                    ps.setBoolean(14, user.isUseInternalPhoneForC2C());
                    ps.setString(15, user.getPersonnelNumber());
                    ps.setString(16, user.getSubdivision());
                    ps.setString(17, user.getSberPdi());
                });
        // Delete user roles
        String deleteRolesSql = "delete from user_role where sber_pdi = ?";
        jdbc.update(deleteRolesSql, ps -> ps.setString(1, user.getSberPdi()));
        // Add user roles
        saveRoles(user.getSberPdi(), new ArrayList<>(user.getRoles()));
        // Delete credit types
        String deleteCreditTypesSql = "delete from user_credit_type where sber_pdi = ?";
        jdbc.update(deleteCreditTypesSql, ps -> ps.setString(1, user.getSberPdi()));
        // Add credit types
        saveCreditTypes(user.getSberPdi(), new ArrayList<>(user.getCreditTypes()));
        // Delete absence
        String deleteAbsenceSql = "delete from user_absence where sber_pdi = ?";
        jdbc.update(deleteAbsenceSql, ps -> ps.setString(1, user.getSberPdi()));
        // Add absence
        saveAbsence(user.getSberPdi(), user.getAbsence());
    }

    private void saveRoles(String sberPdi, List<String> roles) {
        String sql = "insert into user_role (sber_pdi, role) values (?,?)";
        jdbc.batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                ps.setString(1, sberPdi);
                ps.setString(2, roles.get(i));
            }

            @Override
            public int getBatchSize() {
                return roles.size();
            }
        });
    }

    private void saveCreditTypes(String sberPdi, List<String> creditTypes) {
        String sql = "insert into user_credit_type (sber_pdi, credit_type_code) values (?,?)";
        jdbc.batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                ps.setString(1, sberPdi);
                ps.setString(2, creditTypes.get(i));
            }

            @Override
            public int getBatchSize() {
                return creditTypes.size();
            }
        });
    }

    private void saveAbsence(String sberPdi, List<AbsencePeriod> absencePeriods) {
        String sql = "insert into user_absence (sber_pdi, start_date, end_date) values (?,?,?)";
        jdbc.batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                LocalDate start = absencePeriods.get(i).getStart();
                LocalDate end = absencePeriods.get(i).getEnd();
                ps.setString(1, sberPdi);
                ps.setDate(2, start == null ? null : Date.valueOf(start));
                ps.setDate(3, end == null ? null : Date.valueOf(end));
            }

            @Override
            public int getBatchSize() {
                return absencePeriods.size();
            }
        });
    }

    private void saveCasbinGroups(User user) {
        user.getRoles().forEach(role ->
                enforcer.addRoleForUserInDomain(user.getSberPdi(), role, CasbinAuthDomains.ANY_DOMAIN)
        );
    }

    private void mergeCasbinGroups(User user) {
        Set<String> casbinRoles = new HashSet<>(enforcer.getRolesForUser(user.getSberPdi()));

        if (!casbinRoles.equals(user.getRoles())) {
            enforcer.deleteRolesForUser(user.getSberPdi());
            saveCasbinGroups(user);
        }
    }
}
