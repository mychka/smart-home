package ru.sbrf.klt.sudir.kalita.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import ru.sbrf.klt.sudir.kalita.service.KalitaSudirService;

@Configuration
public class KalitaSudirServiceConfig {

    @Value("${kalita.wsdl.host}")
    private String host;

    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath("ru.sbrf.klt.sudir.kalita.xml");
        return marshaller;
    }

    @Bean
    public KalitaSudirService kalitaSudirService(Jaxb2Marshaller marshaller) {
        KalitaSudirService client = new KalitaSudirService();
        client.setDefaultUri(host);
        client.setMarshaller(marshaller);
        client.setUnmarshaller(marshaller);
        return client;
    }
}
