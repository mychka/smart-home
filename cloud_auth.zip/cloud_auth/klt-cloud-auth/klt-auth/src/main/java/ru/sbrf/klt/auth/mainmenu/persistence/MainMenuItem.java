package ru.sbrf.klt.auth.mainmenu.persistence;

public record MainMenuItem (
    String id,
    String path,
    String displayName
) {
}
