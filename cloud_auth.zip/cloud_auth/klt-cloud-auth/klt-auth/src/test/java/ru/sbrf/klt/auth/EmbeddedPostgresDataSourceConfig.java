package ru.sbrf.klt.auth;

import com.opentable.db.postgres.embedded.EmbeddedPostgres;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.cloud.function.utils.SocketUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

import javax.sql.DataSource;
import java.io.IOException;

@TestConfiguration
public class EmbeddedPostgresDataSourceConfig {

    @Bean
    @Primary
    DataSource getInternalDataSource() throws IOException {
        return EmbeddedPostgres.builder()
                .setPort(SocketUtils.findAvailableTcpPort())
                .start()
                .getPostgresDatabase();
    }
}
