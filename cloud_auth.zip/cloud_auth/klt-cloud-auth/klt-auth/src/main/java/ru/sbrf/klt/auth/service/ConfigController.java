package ru.sbrf.klt.auth.service;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/config")
public class ConfigController {

    @Autowired
    private ConfigService nginxConfig;

    @GetMapping(path = "/app", produces = MediaType.MULTIPART_FORM_DATA_VALUE)
    public String getConfig() {
        return nginxConfig.getConfig();
    }
}