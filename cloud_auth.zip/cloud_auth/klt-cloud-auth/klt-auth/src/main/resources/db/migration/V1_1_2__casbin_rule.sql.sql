insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Ассистент Инспектора СИП', '/klt-auth/mainmenu', 'sip', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Ассистент Инспектора СИП' and v1 = '/klt-auth/mainmenu' and v2 = 'sip' and v3 = 'read');

insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Региональный менеджер ОСИП', '/klt-auth/mainmenu', 'sip', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Региональный менеджер ОСИП' and v1 = '/klt-auth/mainmenu' and v2 = 'sip' and v3 = 'read');