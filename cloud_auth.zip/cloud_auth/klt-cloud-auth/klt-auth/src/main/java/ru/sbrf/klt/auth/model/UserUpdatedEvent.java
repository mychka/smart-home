package ru.sbrf.klt.auth.model;

import java.time.LocalDateTime;

public class UserUpdatedEvent extends UserEvent {
    public static final String TYPE = "USER_UPDATED";

    public UserUpdatedEvent() {
        setType(TYPE);
        setTimestamp(LocalDateTime.now());
    }

    public UserUpdatedEvent(User user) {
        this();
        setUser(user);
    }
}
