package ru.sbrf.klt.auth.service;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

@Configuration
public class Config {

    @Bean
    @Qualifier("KalitaDataSource")
    DataSource getKalitaDataSource(@Value("${kalita.datasource.embedded}") boolean embedded,
                                   @Value("${kalita.datasource.driver-class-name}") String driverClass,
                                   @Value("${kalita.datasource.url}") String url,
                                   @Value("${kalita.datasource.username}") String username,
                                   @Value("${kalita.datasource.password}") String password,
                                   @Value("${kalita.datasource.maximum-pool-size}") int poolSize) {
        if (embedded) {
            EmbeddedDatabase embeddedDatabase = new EmbeddedDatabaseBuilder()
                    .setType(EmbeddedDatabaseType.H2)
                    .generateUniqueName(true)
                    .addScript("init_kalita_db.sql")
                    .build();
            HikariConfig config = new HikariConfig();
            config.setDataSource(embeddedDatabase);
            config.setMaximumPoolSize(poolSize);
            return new HikariDataSource(config);
        } else {
            HikariConfig config = new HikariConfig();
            config.setJdbcUrl(url);
            config.setUsername(username);
            config.setPassword(password);
            config.setDriverClassName(driverClass);
            config.setMaximumPoolSize(poolSize);
            return new HikariDataSource(config);
        }
    }

    @Bean
    @Primary
    DataSource getInternalDataSource(@Value("${internal.datasource.driver-class-name}") String driverClass,
                                     @Value("${internal.datasource.url}") String url,
                                     @Value("${internal.datasource.username}") String username,
                                     @Value("${internal.datasource.password}") String password,
                                     @Value("${internal.datasource.maximum-pool-size}") int poolSize) {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(url);
        config.setUsername(username);
        config.setPassword(password);
        config.setDriverClassName(driverClass);
        config.setMaximumPoolSize(poolSize);
        return new HikariDataSource(config);
    }

    @Bean
    public PlatformTransactionManager txManager(@Autowired DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }
}
