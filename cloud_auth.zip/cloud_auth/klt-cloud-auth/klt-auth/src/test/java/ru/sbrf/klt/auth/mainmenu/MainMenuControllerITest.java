package ru.sbrf.klt.auth.mainmenu;

import org.casbin.jcasbin.main.Enforcer;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.transaction.annotation.Transactional;
import ru.sbrf.klt.auth.AbstractTest;
import ru.sbrf.klt.auth.casbin.CasbinAuthDomains;
import ru.sbrf.klt.auth.mainmenu.persistence.MainMenuItem;
import ru.sbrf.klt.auth.mainmenu.persistence.MainMenuItemDao;
import ru.sbrf.klt.auth.mainmenu.web.MainMenuController;
import ru.sbrf.klt.auth.mainmenu.web.MainMenuDto;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@Transactional
class MainMenuControllerITest extends AbstractTest {

    @Autowired
    MainMenuController mainMenuController;

    @Autowired
    MainMenuItemDao mainMenuItemDao;

    @Autowired
    Enforcer enforcer;

    @Test
    @WithMockUser(value = "userSberPdi")
    void hasAccessToAllowedMenuItem() {
        //given
        MainMenuDto expectedItem = mainMenu(List.of("role_menu"));
        userHasRoles("userSberPdi", List.of("userRole"));
        roleCanAccessMenuItem("userRole", "role_menu");

        //when
        MainMenuDto items = mainMenuController.userConfig().getBody();

        //then
        assertThat(items).isEqualTo(expectedItem);
    }

    @Test
    @WithMockUser(value = "userSberPdi")
    void canNotAccessRestrictedMenuItem() {
        //given
        MainMenuDto unExpectedItem = mainMenu(List.of("other_role_menu"));
        userHasRoles("userSberPdi", List.of("userRole"));
        assert enforcer.getPermissionsForUser("userSberPdi").size() == 0;

        //when
        MainMenuDto items = mainMenuController.userConfig().getBody();

        //then
        assertThat(items.modules()).isEmpty();
    }

    @Test
    @WithMockUser(value = "userSberPdi")
    void allUserRolesAreTakenIntoAccount() {
        //given
        MainMenuDto expecetedItem = mainMenu(List.of("menuForRole1", "menuForRole2"));
        userHasRoles("userSberPdi", List.of("userRole1", "userRole2"));
        roleCanAccessMenuItem("userRole1", "menuForRole1");
        roleCanAccessMenuItem("userRole2", "menuForRole2");

        //when
        MainMenuDto items = mainMenuController.userConfig().getBody();

        //then
        assertThat(items).isEqualTo(expecetedItem);
    }

    @Test
    @WithMockUser(value = "userSberPdi")
    void canAccessByImplicitUserPermission() {
        //given
        MainMenuDto expectedItem = mainMenu(List.of("role_menu"));
        enforcer.addPolicy("userSberPdi", "role_menu", "read");

        //when
        MainMenuDto items = mainMenuController.userConfig().getBody();

        //then
        assertThat(items).isEqualTo(expectedItem);
    }


    private void userHasRoles(String sberPdi, List<String> roles) {
        roles.forEach(role ->
                enforcer.addRoleForUserInDomain(sberPdi, role, CasbinAuthDomains.ANY_DOMAIN)
        );
    }

    private void roleCanAccessMenuItem(String role, String itemId) {
        enforcer.addPolicy(role, CasbinAuthDomains.MAIN_MAENU_DOMAIN, itemId, "read");
    }

    private MainMenuDto mainMenu(List<String> ids) {
        List<MainMenuItem> items = new ArrayList<>();
        for (String id : ids) {
            MainMenuItem item = new MainMenuItem(id, "/" + id, "push_" + id);
            mainMenuItemDao.addItem(item);
            items.add(item);
        }
        return new MainMenuDto(items);
    }
}