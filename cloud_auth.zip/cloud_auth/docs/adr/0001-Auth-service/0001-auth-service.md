# 1. Временное решение для авторизации

Date: 2022-02-11

## Статус

Предложение

## Контекст

Нужно передавать в сервис добровольной реализации и прочие сервисы взыскания информацию о ролях пользователя.
Аутентификация происходит с помощью IAM.proxy в СУДИР(схема здесь) 
В результате аутентификации на nginx'е фронта мы получаем набор запрос с заголовками:
```http request
    auth-svc-user = 16683794
    Authorization = Bearer eyJraWQiOiJlRlRGbGgwZnA2bmp1ZkljaGlBaXhIdkR1VEpsaXltODh5aG81bmJrdWswIiwiYWxnIjoiUlMyNTYifQ.eyJydF9oYXNoIjoiZGZIX2NfbTR6dzNxcjFvWlpkVW1uUSIsIm5vbmNlIjoiYzZjM2M0NzAyYTI2ZWI5YTcyN2M1MGYxZjZmYzFkNDMiLCJpYXQiOjE2MzkzODM5NjIsImlzcyI6Imh0dHBzOi8vaWRwZGV2LnNpZ21hLnNicmYucnUvIiwiYXRfaGFzaCI6IlpjLWtKZzlGNk5oTmoydWFUb2ItVlEiLCJzdWIiOiIxNjY4Mzc5NCIsImV4cCI6MTYzOTM4NzU2MiwiYXVkIjoiQ0kwMzI4MDY2NSJ9.GBs4wJY5pV-ygMm2D74Olt4pT_C7LiIj-yXK-NeP_NhQ0aV4I7bnjfx6TPYYdrKlidKrg2r7l1sqaYI0PAY1kZfzk1ADKwKNMVKroZxK8AsYnGX8W2B2TysmRwJhpHSEIlDHpa2YhmlNs2OOw80PGCz9SthGms43JCXsRWURxFoT2dCPg06m-8AWhdcoi3cOuRaH8JnbNdW-UXnLTeqJxaX_XcP6sQlOlFo88CcLvmbUdKhs7f4qR-GAbEE8SmcnxXq3w6GRMv3wBDlXa9l1Ja1Vm8E0xEvnxcWl4iO-nBdnM6xEJfAdZFsaltPd_CUhktS2IlU72vpUBhlqMI-xAg
    iv-user = 16683794
```
содержимое токена:
```json
{
  "rt_hash": "dfH_c_m4zw3qr1oZZdUmnQ",
  "nonce": "c6c3c4702a26eb9a727c50f1f6fc1d43",
  "iat": 1639383962,
  "iss": "https://idpdev.sigma.sbrf.ru/",
  "at_hash": "Zc-kJg9F6NhNj2uaTob-VQ",
  "sub": "16683794",
  "exp": 1639387562,
  "aud": "CI03280665"
  // по идее еще должны быть ФИО + почта, но они нам пока по неизвестной причине не приходят
}
```
Так как данных по ролям IAM из СУДИРа не пробрасывает, то необходимо решение для получения списка ролей пользователя в бизнес-сервисах.

## Решение

Проконсультировавшись с коллегами из продукта IAM возникли следующие варианты:
 * Использование Объединенного Сервиса Авторизации. Отклонено, так как подразумевает миграцию на Платформу, влечет за собой много зависимостей и переделку ролевой модели на схему ЕФС
 * Cервис авторизации СУДИР. Отклонен, в силу сроков реализации(2q22) и отсутствия конкретики по решению
 * Использование KeycloakSE в паре с СУДИР с token exchange. Отклонено в силу трудоемкости реализации и плановой даты релиза механизма token exchange в конце 2q22

Ни один из вариантов, предложенных IAM вариантов не подошел по срокам реализации, поэтому выбрано(вероятно временное) решение с самописным сервисом авторизации.
Вводим дополнительный сервис авторизации, который получает данные о ролях из БД Калиты и кладет их в cookie.

![](auth_proprietary.svg)

Последовательность вызовов(взаимодейтсвие IAM-СУДИР для простоты не рассматривается):

![](auth_sequence.svg)

## Последствия

Выбранное решение позволяет минимальными затратами реализовать авторизацию на основании существующей ролевой модели 
и отложить решение о переходе на "целевой" сервис авторизации.

