IS_SBER_OS=$(grep -q SberOS /etc/os-release && echo true)
TEMP_PATH=C:/Users/16731831/work/tmp

export MSYS_NO_PATHCONV=1

echo stop nginx
podman stop nginx
echo remove nginx
podman rm nginx

echo render syngx.conf

if [ $IS_SBER_OS ]; then
  KLT_AUTH_HOST=klt-auth
else
  KLT_AUTH_HOST=localhost
fi

rm -rf $TEMP_PATH/syngx

helm create $TEMP_PATH/syngx
echo "test: |" > $TEMP_PATH/syngx/templates/syngx.tmpl
cat ../_helm_charts/klt-auth/charts/nginx/syngx.tmpl | sed -e 's/^/  /' >> $TEMP_PATH/syngx/templates/syngx.tmpl

helm template -s templates/syngx.tmpl $TEMP_PATH/syngx \
    --set nginx.authUrl=http://$KLT_AUTH_HOST:5001 \
    --set nginx.kibana.url=http://kibana.apps.ift-efs1-dm.delta.sbrf.ru:10084 \
    --set nginx.frontendModules.stlmnt.path=settlement \
    --set nginx.frontendModules.stlmnt.url=https://frontend.ci00372608-edevgen1dm-klt-stlmnt.apps.dev-gen1-dm.delta.sbrf.ru \
    | sed 1,3d | sed -e 's/^  //' > $TEMP_PATH/syngx.conf

echo run container nginx

if [ $IS_SBER_OS ]; then
  RUN_NGINX_FLAGS="--log-driver json-file --network cloud_auth -p 8080:8080"
else
  RUN_NGINX_FLAGS="--pod=cloud_auth"
fi

podman run --read-only -d --name nginx --tls-verify=false $RUN_NGINX_FLAGS \
--volume $TEMP_PATH:/tmp:rw \
--volume $TEMP_PATH:/var/log:rw \
--volume $TEMP_PATH/syngx.conf:/opt/syngx/conf.d/syngx.conf:ro \
nginx:1

read -p "Press enter to continue"