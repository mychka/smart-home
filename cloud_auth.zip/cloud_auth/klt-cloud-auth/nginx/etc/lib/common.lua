local semver = require "semver"

local common = {}

function common.path()
    local uri = ngx.var.uri
    if string.find(uri,"latest") == nil then
        return uri
    else
        return createPath(uri)
    end
end

function createPath(uri)
    local patch = split(uri,"latest")
    local p = "/opt/syngx/html" .. patch[1]
    local maxVersion = semver("0.0.0")
    for dir in io.popen("ls ".. p .." | grep -v /"):lines() do
        local nextVersion = semver(dir)
        if nextVersion > maxVersion then
            maxVersion = nextVersion
        end
    end
    return patch[1] .. tostring(maxVersion) .. patch[2]
end

function split(str, pat)
   local t = {}
   local fpat = "(.-)" .. pat
   local last_end = 1
   local s, e, cap = str:find(fpat, 1)
   while s do
      if s ~= 1 or cap ~= "" then
         table.insert(t, cap)
      end
      last_end = e+1
      s, e, cap = str:find(fpat, last_end)
   end
   if last_end <= #str then
      cap = str:sub(last_end)
      table.insert(t, cap)
   end
   return t
end

return common;