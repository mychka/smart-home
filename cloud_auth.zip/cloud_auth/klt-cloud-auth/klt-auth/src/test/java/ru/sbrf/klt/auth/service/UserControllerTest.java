package ru.sbrf.klt.auth.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.instancio.Instancio;
import org.instancio.junit.InstancioExtension;
import org.instancio.junit.WithSettings;
import org.instancio.settings.Keys;
import org.instancio.settings.Settings;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.sbrf.klt.auth.model.*;
import ru.sbrf.klt.auth.store.external.KalitaDBUserStore;
import ru.sbrf.klt.auth.store.internal.InternalUserStore;
import ru.sbrf.klt.auth.store.internal.InternalUserStoreDao;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.time.Instant;
import java.util.Date;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;
import static org.mockito.Mockito.*;
import static org.springframework.http.HttpStatus.OK;
import static org.springframework.http.HttpStatus.UNAUTHORIZED;
import static ru.sbrf.klt.auth.service.UserController.ACCESS_COOKIE;
import static ru.sbrf.klt.auth.service.UserController.ACCESS_TOKEN;
import static ru.sbrf.klt.auth.store.internal.Action.CREATE;
import static ru.sbrf.klt.auth.store.internal.Action.UPDATE;

@ExtendWith({MockitoExtension.class, InstancioExtension.class})
class UserControllerTest {

    @Mock
    KalitaDBUserStore kalitaDBUserStore;
    @Mock
    KafkaEventPublisher kafkaEventPublisher;
    @Mock
    InternalUserStoreDao internalUserStoreDao;
    @Captor
    protected ArgumentCaptor<UserEvent> userEventCaptor;

    UserController userController;
    JwtService jwtService;

    @WithSettings
    Settings settings = Settings.create()
                                .set(Keys.COLLECTION_MIN_SIZE, 1)
                                .set(Keys.COLLECTION_MAX_SIZE, 1)
                                .lock();

    @BeforeEach
    void init() throws GeneralSecurityException, IOException {
        InternalUserStore internalUserStore = new InternalUserStore(kalitaDBUserStore, kafkaEventPublisher, internalUserStoreDao);
        jwtService = new JwtService("classpath:jwt_keys/private.pem", "123456", "classpath:jwt_keys/public.pem", 3600L, 600L);
        ObjectMapper objectMapper = new ObjectMapper();
        userController = new UserController(internalUserStore, jwtService, objectMapper, kafkaEventPublisher);
    }

    @Test
    @DisplayName("Получение jwk")
    void test1() {
        String jwk = userController.jwk();
        assertThat(jwk).isNotNull();
    }

    @Test
    @DisplayName("Проверяем что пользователя нет во внутреннем и во внешнем хранилище и возвращаем UNAUTHORIZED")
    void test2() {
        ResponseEntity<Object> responseEntity = userController.setJwtToken(authorizationHeader(), "");
        assertThat(responseEntity)
                .isNotNull()
                .satisfies(response -> {
                    assertThat(response.getStatusCode()).isEqualTo(UNAUTHORIZED);
                });
    }

    @Test
    @DisplayName("Заходим с пустым токеном. Проверяем что пользователя нет во внутреннем, но есть во внешнем хранилище и отправлено событие с типом (USER_CREATED,USER_LOGGED_IN), HttpStatus OK и заполненный токен")
    void test3() {
        doReturn(null).when(internalUserStoreDao).findBySberPdi(anyString());
        doReturn(CREATE).when(internalUserStoreDao).createOrUpdateUser(any(User.class));

        User externalUser = Instancio.create(User.class);
        doReturn(externalUser).when(kalitaDBUserStore).findByIdIgnoreCaseOrSberPdi(anyString(), anyString());

        ResponseEntity<Object> responseEntity = userController.setJwtToken(authorizationHeader(), "");
        assertThat(responseEntity)
                .isNotNull()
                .satisfies(response -> {
                    assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
                    assertThat(response.getHeaders()).hasSize(2)
                                                     .satisfies(map -> {
                                                         assertThat(map.get(ACCESS_TOKEN).get(0)).isNotNull();
                                                         assertThat(map.get(ACCESS_COOKIE).get(0)).isNotNull();
                                                     });
                });

        verify(kafkaEventPublisher, times(2)).publish(userEventCaptor.capture());
        List<UserEvent> userEvents = userEventCaptor.getAllValues();
        assertThat(userEvents)
                .isNotNull()
                .hasSize(2)
                .satisfies(userEvents1 -> {
                    assertThat(userEvents1.get(0).getType()).isEqualTo(UserCreatedEvent.TYPE);
                    assertThat(userEvents1.get(1).getType()).isEqualTo(UserLoggedInEvent.TYPE);
                });
    }

    @Test
    @DisplayName("Заходим с пустым токеном. Проверяем что пользователя есть во внутреннем и есть во внешнем хранилище и отправлено событие с типом (USER_UPDATED,USER_LOGGED_IN), HttpStatus OK и заполненный токен ")
    void test4() {
        String id = "1";
        String sberPdi = "2";

        User internalUser = Instancio.create(User.class);
        internalUser.setId(id);
        internalUser.setSberPdi(sberPdi);
        doReturn(internalUser).when(internalUserStoreDao).findBySberPdi(anyString());
        doReturn(UPDATE).when(internalUserStoreDao).createOrUpdateUser(Mockito.any(User.class));

        User externalUser = Instancio.create(User.class);
        externalUser.setId(id);
        externalUser.setSberPdi(sberPdi);
        doReturn(externalUser).when(kalitaDBUserStore).findByIdIgnoreCaseOrSberPdi(anyString(), anyString());

        ResponseEntity<Object> responseEntity = userController.setJwtToken(authorizationHeader(), "");

        assertThat(responseEntity)
                .isNotNull()
                .satisfies(response -> {
                    assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
                    assertThat(response.getHeaders()).hasSize(2)
                                                     .satisfies(map -> {
                                                         assertThat(map.get(ACCESS_TOKEN).get(0)).isNotNull();
                                                         assertThat(map.get(ACCESS_COOKIE).get(0)).isNotNull();
                                                     });
                });

        await().until(() -> {
                          verify(kafkaEventPublisher, times(2)).publish(userEventCaptor.capture());
                          return userEventCaptor.getAllValues();
                      },
                      events -> events.size() == 2
        );
    }

    @Test
    @DisplayName("Заходим с токеном. Проверяем что пользователя есть во внутреннем и есть во внешнем хранилище и отправлено событие с типом (USER_UPDATED), HttpStatus OK и заполненный токен ")
    void test5() {
        String id = "1";
        String sberPdi = "2";

        User internalUser = Instancio.create(User.class);
        internalUser.setId(id);
        internalUser.setSberPdi(sberPdi);
        doReturn(internalUser).when(internalUserStoreDao).findBySberPdi(anyString());
        doReturn(UPDATE).when(internalUserStoreDao).createOrUpdateUser(Mockito.any(User.class));

        User externalUser = Instancio.create(User.class);
        externalUser.setId(id);
        externalUser.setSberPdi(sberPdi);
        doReturn(externalUser).when(kalitaDBUserStore).findByIdIgnoreCaseOrSberPdi(anyString(), anyString());

        ResponseEntity<Object> responseEntity = userController.setJwtToken(authorizationHeader(), createTokenSignedWithCorrectKey(internalUser));

        assertThat(responseEntity)
                .isNotNull();

        await().until(() -> {
                          verify(kafkaEventPublisher, times(1)).publish(userEventCaptor.capture());
                          return userEventCaptor.getValue();
                      },
                      event -> event.getType().equals(UserUpdatedEvent.TYPE)
        );
    }

    @Test
    @DisplayName("Заходим с просроченным токеном. Проверяем что пользователя есть во внутреннем и есть во внешнем хранилище и отправлено событие с типом (USER_UPDATED), HttpStatus UNAUTHORIZED")
    void test6() {
        String id = "1";
        String sberPdi = "2";

        User internalUser = Instancio.create(User.class);
        internalUser.setId(id);
        internalUser.setSberPdi(sberPdi);
        doReturn(internalUser).when(internalUserStoreDao).findBySberPdi(anyString());
        doReturn(UPDATE).when(internalUserStoreDao).createOrUpdateUser(Mockito.any(User.class));

        User externalUser = Instancio.create(User.class);
        externalUser.setId(id);
        externalUser.setSberPdi(sberPdi);
        doReturn(externalUser).when(kalitaDBUserStore).findByIdIgnoreCaseOrSberPdi(anyString(), anyString());

        ResponseEntity<Object> responseEntity = userController.setJwtToken(authorizationHeader(), createExpiredToken(internalUser));

        assertThat(responseEntity)
                .isNotNull()
                .satisfies(response -> {
                    assertThat(response.getStatusCode()).isEqualTo(UNAUTHORIZED);
                });

        await().until(() -> {
                          verify(kafkaEventPublisher, times(1)).publish(userEventCaptor.capture());
                          return userEventCaptor.getValue();
                      },
                      event -> event.getType().equals(UserUpdatedEvent.TYPE)
        );
    }

    @Test
    @DisplayName("Заходим не с просроченным токеном. HttpStatus OK")
    void test7() {
        String id = "1";
        String sberPdi = "2";

        User internalUser = Instancio.create(User.class);
        internalUser.setId(id);
        internalUser.setSberPdi(sberPdi);
        doReturn(internalUser).when(internalUserStoreDao).findBySberPdi(anyString());
        doReturn(UPDATE).when(internalUserStoreDao).createOrUpdateUser(Mockito.any(User.class));

        User externalUser = Instancio.create(User.class);
        externalUser.setId(id);
        externalUser.setSberPdi(sberPdi);
        doReturn(externalUser).when(kalitaDBUserStore).findByIdIgnoreCaseOrSberPdi(anyString(), anyString());

        ResponseEntity<Object> responseEntity = userController.setJwtToken(authorizationHeader(), createNotExpiredToken(internalUser));

        assertThat(responseEntity)
                .isNotNull()
                .satisfies(response -> {
                    assertThat(response.getStatusCode()).isEqualTo(OK);
                });
    }

    private String createTokenSignedWithCorrectKey(User user) {
        return jwtService.generateTokenPair(user, null).getAccessToken();
    }

    private String createExpiredToken(User user) {
        Date exp = Date.from(Instant.ofEpochSecond(new java.util.Date().getTime()/1000-jwtService.getDeltaExpAccessToken()));
        return jwtService.generateTokenPair(user, exp).getAccessToken();
    }

    private String createNotExpiredToken(User user) {
        Date exp = Date.from(Instant.ofEpochSecond(new java.util.Date().getTime()/1000+jwtService.getDeltaExpAccessToken()/2));
        return jwtService.generateTokenPair(user, exp).getAccessToken();
    }

    private String authorizationHeader() {
        return "Bearer eyJraWQiOiJlRlRGbGgwZnA2bmp1ZkljaGlBaXhIdkR1VEpsaXltODh5aG81bmJrdWswIiwiYWxnIjoiUlMyNTYifQ.eyJydF9oYXNoIjoiZGZIX2NfbTR6dzNxcjFvWlpkVW1uUSIsIm5vbmNlIjoiYzZjM2M0NzAyYTI2ZWI5YTcyN2M1MGYxZjZmYzFkNDMiLCJpYXQiOjE2MzkzODM5NjIsImlzcyI6Imh0dHBzOi8vaWRwZGV2LnNpZ21hLnNicmYucnUvIiwiYXRfaGFzaCI6IlpjLWtKZzlGNk5oTmoydWFUb2ItVlEiLCJzdWIiOiJ0ZXN0dXNlciIsImV4cCI6MTYzOTM4NzU2MiwiYXVkIjoiQ0kwMzI4MDY2NSIsICJzYmVycGRpIjoiMTIzNDU2NzgifQ==.GBs4wJY5pV-ygMm2D74Olt4pT_C7LiIj-yXK-NeP_NhQ0aV4I7bnjfx6TPYYdrKlidKrg2r7l1sqaYI0PAY1kZfzk1ADKwKNMVKroZxK8AsYnGX8W2B2TysmRwJhpHSEIlDHpa2YhmlNs2OOw80PGCz9SthGms43JCXsRWURxFoT2dCPg06m-8AWhdcoi3cOuRaH8JnbNdW-UXnLTeqJxaX_XcP6sQlOlFo88CcLvmbUdKhs7f4qR-GAbEE8SmcnxXq3w6GRMv3wBDlXa9l1Ja1Vm8E0xEvnxcWl4iO-nBdnM6xEJfAdZFsaltPd_CUhktS2IlU72vpUBhlqMI-xAg";
    }
}