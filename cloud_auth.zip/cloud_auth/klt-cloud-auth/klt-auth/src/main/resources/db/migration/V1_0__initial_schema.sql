create table user_data
(
    sber_pdi text not null primary key,
    id text not null,
    personnel_number text,
    last_name text,
    first_name text,
    middle_name text,
    email text,
    time_zone text,
    working_day_start_time text,
    working_day_end_time text,
    sum_limit_from numeric(19,2),
    sum_limit_to numeric(19,2),
    external_phone text,
    internal_phone text,
    use_internal_phone_for_c2c boolean default false,
    subdivision_code text,
    is_deleted boolean default false
);

create index idx_user_data_id_upper on user_data (upper(id));

comment on table user_data is 'Таблица пользователей';
comment on column user_data.sber_pdi is 'Sber PDI';
comment on column user_data.id is 'Id';
comment on column user_data.personnel_number is 'Табельный номер';
comment on column user_data.last_name is 'Фамилия';
comment on column user_data.first_name is 'Имя';
comment on column user_data.middle_name is 'Отчество';
comment on column user_data.email is 'Электронная почта';
comment on column user_data.time_zone is 'Часовой пояс';
comment on column user_data.working_day_start_time is 'Рабочее время с';
comment on column user_data.working_day_end_time is 'Рабочее время по';
comment on column user_data.sum_limit_from is 'Лимит обработки по суммам задолженности от';
comment on column user_data.sum_limit_to is 'Лимит обработки по суммам задолженности до';
comment on column user_data.external_phone is 'Внешний номер телефона';
comment on column user_data.internal_phone is 'Внутренний номер телефона';
comment on column user_data.use_internal_phone_for_c2c is 'Использовать внутренний номер телефона для Click2Call';
comment on column user_data.subdivision_code is 'Код подразделения';
comment on column user_data.is_deleted is 'Удалён';

create table user_role
(
    sber_pdi text not null,
    role text not null,
    unique (sber_pdi, role)
);
create index idx_user_role_sber_pdi on user_role (sber_pdi);

create table user_credit_type
(
    sber_pdi text not null,
    credit_type_code text not null,
    unique (sber_pdi, credit_type_code)
);
create index idx_user_credit_type_sber_pdi on user_credit_type (sber_pdi);

create table user_absence
(
    sber_pdi text not null,
    start_date date,
    end_date date
);
create index idx_user_absence_sber_pdi on user_absence (sber_pdi);
