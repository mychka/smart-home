package ru.sbrf.klt.auth.casbin;

import org.casbin.jcasbin.main.Enforcer;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class CasbinPolicyRefresher {

    private final Enforcer enforcer;

    public CasbinPolicyRefresher(Enforcer enforcer) {
        this.enforcer = enforcer;
    }

    @Transactional
    @Scheduled(initialDelayString = "${casbin.initialDelay.ms}", fixedDelayString = "${casbin.fixedDelay.ms}")
    public void refreshPolicy() {
        enforcer.loadPolicy();
    }
}
