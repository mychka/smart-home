insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Сотрудник ИППЗ', '/klt-auth/mainmenu', 'sip-ippz', 'read'
where not exists (select id
                  from casbin_rule
                  where ptype = 'p'
                    and v0 = 'Сотрудник ИППЗ'
                    and v1 = '/klt-auth/mainmenu'
                    and v2 = 'sip-ippz'
                    and v3 = 'read');

insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Сотрудник ПУПЗ ЮЛ', '/klt-auth/mainmenu', 'sip-ippz', 'read'
where not exists (select id
                  from casbin_rule
                  where ptype = 'p'
                    and v0 = 'Сотрудник ПУПЗ ЮЛ'
                    and v1 = '/klt-auth/mainmenu'
                    and v2 = 'sip-ippz'
                    and v3 = 'read');

insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Руководитель ОСИП ТБ', '/klt-auth/mainmenu', 'sip-ippz', 'read'
where not exists (select id
                  from casbin_rule
                  where ptype = 'p'
                    and v0 = 'Руководитель ОСИП ТБ'
                    and v1 = '/klt-auth/mainmenu'
                    and v2 = 'sip-ippz'
                    and v3 = 'read');

insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Инспектор ПРПА (банкротство)', '/klt-auth/mainmenu', 'sip-ippz', 'read'
where not exists (select id
                  from casbin_rule
                  where ptype = 'p'
                    and v0 = 'Инспектор ПРПА (банкротство)'
                    and v1 = '/klt-auth/mainmenu'
                    and v2 = 'sip-ippz'
                    and v3 = 'read');

insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Главный специалист сопровождения процедуры банкротства', '/klt-auth/mainmenu', 'sip-ippz', 'read'
where not exists (select id
                  from casbin_rule
                  where ptype = 'p'
                    and v0 = 'Главный специалист сопровождения процедуры банкротства'
                    and v1 = '/klt-auth/mainmenu'
                    and v2 = 'sip-ippz'
                    and v3 = 'read');

insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Руководитель списания УСПК КМС', '/klt-auth/mainmenu', 'sip-ippz', 'read'
where not exists (select id
                  from casbin_rule
                  where ptype = 'p'
                    and v0 = 'Руководитель списания УСПК КМС'
                    and v1 = '/klt-auth/mainmenu'
                    and v2 = 'sip-ippz'
                    and v3 = 'read');

insert into casbin_rule(ptype, v0, v1, v2, v3)
select 'p', 'Сотрудник УАК', '/klt-auth/mainmenu', 'sip-ippz', 'read'
where not exists (select id
                  from casbin_rule
                  where ptype = 'p'
                    and v0 = 'Сотрудник УАК'
                    and v1 = '/klt-auth/mainmenu'
                    and v2 = 'sip-ippz'
                    and v3 = 'read');

delete
from casbin_rule
where ptype = 'p'
  and v1 = '/klt-auth/mainmenu'
  and v2 = 'sip-ippz'
  and v3 = 'read'
  and v0 in ('Инспектор ПСИП-Пилот', 'Инспектор ОСИП - пилот ПЦП', 'Руководитель ОСИП - пилот ПЦП',
             'Ассистент Инспектора СИП', 'Руководитель ПСИП-Пилот', 'Аудитор', 'Региональный менеджер ПСИП-Пилот');