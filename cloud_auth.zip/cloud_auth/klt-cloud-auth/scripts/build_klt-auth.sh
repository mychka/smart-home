echo build container
podman build -f ../klt-auth/Dockerfile -t klt-auth:1 --tls-verify=false

read -p "Press enter to continue"