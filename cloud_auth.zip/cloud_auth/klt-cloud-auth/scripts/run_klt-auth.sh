IS_SBER_OS=$(grep -q SberOS /etc/os-release && echo true)

export MSYS_NO_PATHCONV=1
echo run container klt-auth

if [ $IS_SBER_OS ]; then
  RUN_KLT_AUTH_FLAGS="--log-driver json-file --network cloud_auth -p 5001:5001"
  POSTGRES_HOST=postgres
else
  RUN_KLT_AUTH_FLAGS="--pod=cloud_auth"
  POSTGRES_HOST=localhost
fi

podman run -d --name klt-auth --restart always --tls-verify=false $RUN_KLT_AUTH_FLAGS \
-e SPRING_PROFILES_ACTIVE=dev \
-e SPRING_KAFKA_BOOTSTRAP_SERVERS=tkldq-kalit0010.delta.sbrf.ru:9092,tkldq-kalit0011.delta.sbrf.ru:9092 \
-e SPRING_KAFKA_TOPIC_OUTBOUND_NAME=KltAuthUserEvents \
-e INTERNAL_DATASOURCE_URL=jdbc:postgresql://$POSTGRES_HOST:5432/postgres \
-e SERVER_PORT=5001 \
-e KLT_AUTH_PRIVATE_KEY_PATH=file:/app/jwt_keys/private.pem \
-e KLT_AUTH_PUBLIC_KEY_PATH=file:/app/jwt_keys/public.pem \
-e KLT_AUTH_PRIVATE_KEY_PASSWORD=123456 \
--volume ../klt-auth/src/test/resources/jwt_keys/private.pem:/app/jwt_keys/private.pem:ro \
--volume ../klt-auth/src/test/resources/jwt_keys/public.pem:/app/jwt_keys/public.pem:ro \
klt-auth:1

read -p "Press enter to continue"