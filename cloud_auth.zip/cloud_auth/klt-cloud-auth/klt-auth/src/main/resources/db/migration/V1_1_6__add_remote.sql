insert into user_main_menu select 'remote','/remote', 'КЦ'
where not exists (select id from user_main_menu where id ='remote');

insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Бизнес-аналитик', '/klt-auth/mainmenu', 'remote', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Бизнес-аналитик' and v1 = '/klt-auth/mainmenu' and v2 = 'remote' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'Администратор', '/klt-auth/mainmenu', 'remote', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'Администратор' and v1 = '/klt-auth/mainmenu' and v2 = 'remote' and v3 = 'read');
insert into casbin_rule(ptype, v0, v1, v2, v3)
    select 'p', 'ЦСДВ Сотрудник Call-центра', '/klt-auth/mainmenu', 'remote', 'read'
    where not exists (select id from casbin_rule where ptype='p' and v0 = 'ЦСДВ Сотрудник Call-центра' and v1 = '/klt-auth/mainmenu' and v2 = 'remote' and v3 = 'read');