package ru.sbrf.klt.auth.casbin;

import org.casbin.adapter.JDBCAdapter;
import org.casbin.jcasbin.main.Enforcer;
import org.casbin.jcasbin.model.Model;
import org.casbin.jcasbin.persist.Adapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.scheduling.annotation.EnableScheduling;

import javax.sql.DataSource;
import java.io.IOException;

@Configuration
@EnableScheduling
public class CasbinConfig {

    private static final Logger logger = LoggerFactory.getLogger(CasbinConfig.class);

    @Autowired
    DataSource dataSource;

    @Value("classpath:casbin/rbac_with_domains_model.conf")
    Resource modelFile;

    @Bean
    public Adapter autoConfigJdbcAdapter(DataSource dataSource) throws Exception {
            return new JDBCAdapter(dataSource);
    }

    @Bean
    public Enforcer enforcer(Adapter adapter) {
        Model model = new Model();
        try {
            String modelContext = new String(modelFile.getInputStream().readAllBytes());

            model.loadModelFromText(modelContext);
        } catch (IOException e) {
            // if the local model file address is not set or the file is not found in the default path, the default rbac configuration is used
            logger.warn("Can't find model config file, use default model config");
            // request definition
            model.addDef("r", "r", "sub, dom, obj, act");
            // policy definition
            model.addDef("p", "p", "sub, dom, obj, act");
            // role definition
            model.addDef("g", "g", "_, _, _");
            // policy effect
            model.addDef("e", "e", "some(where (p.eft == allow))");
            // matchers
            model.addDef("m", "m", "g(r.sub, p.sub, r.dom) && keyMatch(r.dom, p.dom) && r.obj == p.obj && r.act == p.act");
        }

        Enforcer enforcer = new Enforcer(model, adapter);
        enforcer.enableAutoSave(true);
        return enforcer;
    }
}
