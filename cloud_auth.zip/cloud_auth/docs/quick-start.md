# Подключение фронтенда

## Deployment схема

Статика локальных фронтов разворачивается отдельно в проекте каждой ФП для обеспечения независимости релизов

<img src="diagrams/deployment.png"/>
<br>

## Как идет запрос до back'а ФП

<img src="diagrams/seq_load_module.svg"/>
<br/>

* [1-2] загрузка оркестартора фронта
* [3-4] загрузка основного конфига
* [5-6] загрузка зависимостей из конфига
* [7-8] загрузка доступных пользователю вкладок
* [9-17] загрузка статики ФП и вызовы api

## Что нужно для старта

1. Определиться с ключом своего приложения(module_key) - это условное имя модуля(например для ИДУ - "settlement"), которое будет использоваться в конфигурациях и в url'ах. 

2. Развернуть в своем проекте nginx со статикой по
образу https://stash.delta.sbrf.ru/projects/CLT/repos/cloud_stlmnt/browse/stlmnt-infrastructure-frontend-app
Каждая ФП должна выставлять наружу route'ы вида
```
https://module-route/statics/${module_key}
https://module-route/api/${module_key}
```
то есть, должны быть инструкции nginx
```
        location /api/${module_key} {
            ...
        }

        location /statics/${module_key} {
            ...
        }
```

3. Сообщить в ядровую команду ключ модуля и url route'а для проксирования вызовов



## Обработка токена
Сервис авторизации добавляет в cookie 'access_token' jwt-токен с информацией о пользователе. Состав токена:

```json
{
  "firstName": "Иван",
  "middleName": "Иванович",
  "lastName": "Иванов",
  "pdi": "123456789",
  "roles": [
    "Инспектор гаджет"
  ],
  "iss": "CI00372472",
  "sub": "inspector_99",
  "exp": 1687170704
}
```

### Декодирование токена пользователя
Токен находится в сжатом формате. Для того,чтобы его разобрать нужно выполнить код(в classpath должна быть либа io.jsonwebtoken.jjwt-impl):

```java
import io.jsonwebtoken.CompressionCodecs;
import io.jsonwebtoken.impl.Base64UrlCodec;

String decodedJwt=new String(
        CompressionCodecs.DEFLATE.decompress(
        Base64UrlCodec.BASE64URL.decode(tokenString) //tokenString - payload токена(средняя часть между точками)
        ));
```
