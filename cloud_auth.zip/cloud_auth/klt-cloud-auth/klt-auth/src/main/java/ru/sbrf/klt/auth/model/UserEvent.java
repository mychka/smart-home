package ru.sbrf.klt.auth.model;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public abstract class UserEvent {
    private String type;
    private LocalDateTime timestamp;
    private User user;
}
