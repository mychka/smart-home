package ru.sbrf.klt.sudir.kalita.dict;

public interface SudirConstants {

    String FIRST_NAME_ATTRIBUTE = "firstName";
    String LAST_NAME_ATTRIBUTE = "lastName";
    String MIDDLE_NAME_ATTRIBUTE = "middleName";

    String ROLE_OBJECT="ROLE";
    String FOS_OBJECT="ORGUNIT";

    String ROLE_ID = "roleId";
    String ROLE_NAME = "roleName";
    String ROLE_STATUS = "roleIsArchive";
    String ROLE_MOBILE = "roleIsMobile";
    String ROLE_ARCHIVED = "1";
    String ROLE_NOT_ARCHIVED = "0";
    String ROLE_IS_MOBILE = "1";
    String ROLE_IS_NOT_MOBILE = "0";

    String ORG_UNIT_ID = "fosId";
    String ORG_UNIT_NAME = "fosName";
    String ORG_UNIT_STATUS = "fosIsArchive";
    String ORG_UNIT_ARCHIVED = "1";
    String ORG_UNIT_NOT_ARCHIVED = "0";

    String ACCOUNT_ACTIVE_ATTR = "status";

    String LOGIN = "login";
    String POSITION = "position";
    String FOS = "fos";
    String LAST_LOGIN_DATE = "lastLoginDate";
    String AVAYA_LOGIN = "AvayaLogin";
    String PERSONNEL_NUMBER = "tn";
    String CHIEF_PERSONNEL_NUMBER = "managertn";
    String EMAIL = "mail";

    String ROLE_CONTAINER = "roles";

    String SUSPENDED = "1";
    String NOT_SUSPENDED = "0";

    String USER_SUSPENDED_GROUP_NAME = "Пользователь удален";

    String ATTR_TYPE_STRING = "1";

    int PERSONNEL_NUMBER_LENGTH = 8;
}
