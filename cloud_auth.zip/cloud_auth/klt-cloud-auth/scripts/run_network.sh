IS_SBER_OS=$(grep -q SberOS /etc/os-release && echo true)

export MSYS_NO_PATHCONV=1

echo create network

if [ $IS_SBER_OS ]; then
  podman network create cloud_auth
else
  podman pod create --name cloud_auth -p 5432:5432 -p 8080:8080 -p 5001:5001
fi

echo run postgres

if [ $IS_SBER_OS ]; then
  RUN_POSTGRES_FLAGS="--log-driver json-file --network cloud_auth -p 5432:5432"
else
  RUN_POSTGRES_FLAGS="--pod=cloud_auth"
fi

podman run --name postgres --restart always --tls-verify=false $RUN_POSTGRES_FLAGS \
-e POSTGRES_PASSWORD=postgres -d registry-ci.delta.sbrf.ru/base/docker.io/postgres:16.3-alpine3.20

read -p "Press enter to continue"