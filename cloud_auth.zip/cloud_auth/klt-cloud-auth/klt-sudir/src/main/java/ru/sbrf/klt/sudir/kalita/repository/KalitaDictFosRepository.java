package ru.sbrf.klt.sudir.kalita.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sbrf.klt.sudir.kalita.entity.RegionalBankCodeDict;

import java.util.stream.Stream;


/**
 * Репозиторий спавочника DICT_REG_BANK_CODE
 */
@Repository
public interface KalitaDictFosRepository extends JpaRepository<RegionalBankCodeDict, String> {

    /**
     * Получить значния справочника ACT_ID_GROUP
     *
     * @param offset - startIndex
     * @param limit - размер окна
     * @return - поток KalitaSudirUser
     */
    @Query( value = "select * from DICT_REG_BANK_CODE OFFSET :offset rows fetch next :limit rows only",nativeQuery = true)
    Stream<RegionalBankCodeDict> getFosPage(@Param("offset") int offset, @Param("limit") int limit);

    /**
     * Получить количество активных пользователей
     *
     * @return - int - количество активных пользователей
     */
    @Query( "select count(u) from RegionalBankCodeDict u" )
    int getFosCount();

}
