delete from user_absence;
delete from user_credit_type;
delete from user_role;
delete from user_data;
delete from casbin_rule where ptype = 'g';
