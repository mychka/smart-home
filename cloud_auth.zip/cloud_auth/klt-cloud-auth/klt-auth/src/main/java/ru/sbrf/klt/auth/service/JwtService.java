package ru.sbrf.klt.auth.service;

import io.jsonwebtoken.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import ru.sbrf.klt.auth.crypto.RSAKeyUtil;
import ru.sbrf.klt.auth.model.User;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;

@Slf4j
@Component
public class JwtService {

    private static final String TOKEN_ISSUER = "CI00372472";
    private static final String COOKIE_FORMAT = "%s=%s;Max-Age=%d;HttpOnly;Path=/";

    private final PrivateKey privateKey;
    private final PublicKey publicKey;
    private final Long atLifetimeSeconds;
    @Value("${klt.auth.access-token.compress:false}")
    private boolean compressAccessToken;
    public final Long deltaExpAccessToken;

    public JwtService(@Value("${klt.auth.private-key.path}") String privateKeyPath,
                      @Value("${klt.auth.private-key.password}") String privateKeyPassword,
                      @Value("${klt.auth.public-key.path}") String publicKeyPath,
                      @Value("${klt.auth.access-token.lifetime-seconds}") Long atLifetimeSeconds,
                      @Value("${klt.auth.access-token.delta-exp-seconds}") Long deltaExpAccessToken) throws GeneralSecurityException, IOException {
        privateKey = RSAKeyUtil.getEncryptedPrivateKey(privateKeyPath, privateKeyPassword);
        publicKey = RSAKeyUtil.getPublicKey(publicKeyPath);
        this.atLifetimeSeconds = atLifetimeSeconds;
        this.deltaExpAccessToken = deltaExpAccessToken;
    }

    public JwtToken generateTokenPair(User user, Date expiry) {
        return new JwtToken(buildJwtAccessToken(user, expiry));
    }

    /**
     * Generates new access token given a refresh token
     *
     * @param user - token bearer
     * @return JwtToken
     * @throws IllegalArgumentException when refresh token is invalid or expired
     */
    public JwtToken refreshToken(User user, Date expiry) throws IllegalArgumentException {
        return new JwtToken(buildJwtAccessToken(user, expiry));
    }

    public boolean isValidTokenForUser(String accessToken, String userName) throws ExpiredJwtException {
        if (isValidToken(accessToken)) {
            Claims claims = parseToken(accessToken).getBody();
            return claims.getSubject().equalsIgnoreCase(userName);
        }
        return false;
    }

    public boolean isValidToken(String accessToken) throws ExpiredJwtException {
        try {
            Jwts.parserBuilder()
                    .requireIssuer(TOKEN_ISSUER)
                    .setSigningKey(publicKey)
                    .build()
                    .parseClaimsJws(accessToken);
            return true;
        } catch (IllegalArgumentException e) {
            log.error("JWT claims string is empty: {}", e.getMessage());
        } catch (JwtException e) {
            log.error("JWT token is invalid: {}", e.getMessage());
        }

        return false;
    }

    public String jwk() {
        RSAPublicKey rsaPublicKey = (RSAPublicKey) publicKey;

        return String.format(
                String.join(
                        System.getProperty("line.separator"),
                        "{",
                        "\"keys\" : [",
                        "{",
                        "\"alg\" : \"%s\",",
                        "\"kty\" : \"%s\",",
                        "\"e\" : \"%s\",",
                        "\"n\" : \"%s\"",
                        "}",
                        "]",
                        "}"),
                SignatureAlgorithm.RS256,
                rsaPublicKey.getAlgorithm(),
                Base64.getEncoder().encodeToString(rsaPublicKey.getPublicExponent().toByteArray()),
                Base64.getEncoder().encodeToString(rsaPublicKey.getModulus().toByteArray())
        );
    }

    private String buildJwtAccessToken(User user, Date expiry) {
        if (expiry == null) {
            expiry = new Date(System.currentTimeMillis() + atLifetimeSeconds * 1000);
        }
        HashMap<String, Object> claims = new HashMap<>();
        claims.put("firstName", user.getFirstName());
        claims.put("middleName", user.getMiddleName());
        claims.put("lastName", user.getLastName());
        claims.put("roles", user.getRoles());
        claims.put("pdi", user.getSberPdi());
        JwtBuilder jwtBuilder = Jwts.builder()
                .setHeaderParam("typ", "at+jwt")
                .setClaims(claims)
                .setIssuer(TOKEN_ISSUER)
                .setSubject(user.getId())
                .setExpiration(expiry);

        if (compressAccessToken) {
            jwtBuilder.compressWith(CompressionCodecs.DEFLATE);
        }

        return jwtBuilder.signWith(privateKey, SignatureAlgorithm.RS256).compact();
    }

    public String accessTokenAsCookieString(String tokenName, String tokenValue) {
        return String.format(COOKIE_FORMAT, tokenName, tokenValue, atLifetimeSeconds);
    }

    public Jws<Claims> parseToken(String token) {
        return Jwts.parserBuilder().setSigningKey(publicKey).build().parseClaimsJws(token);
    }

    public Long getDeltaExpAccessToken() {
        return deltaExpAccessToken;
    }
}
