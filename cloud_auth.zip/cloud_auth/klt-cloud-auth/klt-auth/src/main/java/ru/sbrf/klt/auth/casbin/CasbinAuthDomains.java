package ru.sbrf.klt.auth.casbin;

public class  CasbinAuthDomains {
    public static final String ANY_DOMAIN = "*";
    public static final String MAIN_MAENU_DOMAIN = "/klt-auth/mainmenu";

    private CasbinAuthDomains() {}
}
