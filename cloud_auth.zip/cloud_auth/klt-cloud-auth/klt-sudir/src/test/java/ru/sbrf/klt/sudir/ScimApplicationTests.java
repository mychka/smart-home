package ru.sbrf.klt.sudir;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.unboundid.scim2.common.utils.JsonUtils;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import ru.sber.sudir.scim.agent.api.exception.ScimException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import ru.sber.sudir.scim.agent.api.model.SudirFosNode;
import ru.sber.sudir.scim.agent.api.model.SudirRole;
import ru.sber.sudir.scim.agent.api.model.SudirUser;
import ru.sber.sudir.scim.agent.api.service.FosNodeService;
import ru.sber.sudir.scim.agent.api.service.RoleService;
import ru.sber.sudir.scim.agent.api.service.UserService;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ScimApplicationTests extends AbstractTest {

    @Autowired
    private RoleService roleService;

    @Autowired
    private FosNodeService fosService;

    @Autowired
    private UserService userService;

    private ObjectMapper objectMapper;


    @BeforeEach
    void setUp() {
        objectMapper = JsonUtils.createObjectMapper();
    }

    @Test
    public void testServiceRoles() throws ScimException, JsonProcessingException {
        assertEquals(5, roleService.getCount());
        List<SudirRole> roles = roleService.getPage(1, 2);
        assertEquals("[{\"id\":\"1\",\"displayName\":\"ЦСДВ Сотрудник Call-центра\",\"archive\":false}," +
                             "{\"id\":\"2\",\"displayName\":\"ЦСДВ Руководитель отдела\",\"archive\":false}]",
                     objectMapper.writeValueAsString(roles));
    }

    @Test
    public void testServiceFos() throws ScimException, JsonProcessingException {
        assertEquals(3, fosService.getCount());
        List<SudirFosNode> foses = fosService.getPage(1, 2);
        assertEquals("[{\"id\":\"99\",\"displayName\":\"Центральный аппарат\",\"archive\":false}," +
                             "{\"id\":\"02\",\"displayName\":\"Алтайский банкa\",\"archive\":true}]",
                     objectMapper.writeValueAsString(foses));
    }

    @Test
    public void testUserList() throws ScimException, JsonProcessingException {
        assertEquals(3, userService.getCount());
        List<SudirUser> users = userService.getPage(1, 1);
        assertEquals(
                "[{\"id\":\"IVAN\",\"userName\":\"IVAN\",\"familyName\":\"Калита\",\"givenName\":\"Иван\",\"middleName\":\"Викторович\",\"displayName\":\"Калита\",\"title\":" +
                        "\"рабочий\",\"active\":false,\"roles\":[],\"intEmail\":\"test1@sber.ru\",\"employeeNumber\":\"123\",\"fosNodes\":[\"99\"]}]",
                objectMapper.writeValueAsString(users));
    }

}
