package ru.sbrf.klt.auth.store;

import ru.sbrf.klt.auth.model.User;

public interface UserStore {
    User findByIdIgnoreCaseOrSberPdi(String id, String sberPdi);
}
