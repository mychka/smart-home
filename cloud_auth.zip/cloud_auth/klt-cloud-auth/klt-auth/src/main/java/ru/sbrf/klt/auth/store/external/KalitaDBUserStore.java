package ru.sbrf.klt.auth.store.external;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import ru.sbrf.klt.auth.model.AbsencePeriod;
import ru.sbrf.klt.auth.model.User;
import ru.sbrf.klt.auth.store.UserStore;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static java.util.Objects.isNull;
import static org.apache.commons.lang3.StringUtils.trimToNull;

@Component
@Qualifier("Kalita")
public class KalitaDBUserStore implements UserStore {

    private static final Logger log = LoggerFactory.getLogger(KalitaDBUserStore.class);

    private final JdbcTemplate jdbc;

    public KalitaDBUserStore(@Qualifier("KalitaDataSource") DataSource dataSource) {
        jdbc = new JdbcTemplate(dataSource);
    }

    @Override
    public User findByIdIgnoreCaseOrSberPdi(String id, String sberPdi) {
        log.debug("Find user by id = {} or sber pdi = {}", id, sberPdi);
        String userSql = """
                select u.ID_, u.SBER_PDI, u.LAST_, u.FIRST_, u.MIDDLE_NAME_,
                u.IS_DELETED, u.ABSENCE_START_DATE, u.ABSENCE_END_DATE, u.PERSONNEL_NUMBER,
                tz.CODE, s.WORKING_DAY_START_TIME, s.WORKING_DAY_END_TIME, s.SUM_LIMIT_FROM, s.SUM_LIMIT_TO,
                p.EXTERNAL_NUMBER, p.INTERNAL_NUMBER, p.USE_INTERNAL_NUMBER_C2C, sd.CODE as SUBDIVISION,
                ie.INTRABANK_EMAIL as INTRABANK_EMAIL
                from ACT_ID_USER u
                left join USER_SETTLEMENT s on s.USER_ID = u.ID_
                left join DICT_TIMEZONE tz on tz.ID = s.TIMEZONE_ID
                left join INTRABANK_PHONE_NUMBER p on p.USER_ID = u.ID_
                left join DICT_SUBDIVISION sd on sd.ID = u.SUBDIVISION_ID
                left join INTRABANK_EMAIL IE on ie.ID = u.INTRABANK_EMAIL_ID
                where upper(u.ID_) = upper(?) 
                    or upper(u.SBER_PDI) = upper(?)                       
                """;

        List<User> users = jdbc.query(userSql, (rs, rowNum) -> {
            User newUser = new User();
            newUser.setId(rs.getString("ID_"));
            newUser.setSberPdi(rs.getString("SBER_PDI"));
            newUser.setLastName(rs.getString("LAST_"));
            newUser.setFirstName(rs.getString("FIRST_"));
            newUser.setMiddleName(rs.getString("MIDDLE_NAME_"));
            newUser.setEmail(rs.getString("INTRABANK_EMAIL"));
            newUser.setDeleted(rs.getBoolean("IS_DELETED"));
            newUser.setTimeZone(rs.getString("CODE"));
            if (newUser.getTimeZone() == null) {
                newUser.setTimeZone(User.DEFAULT_TIME_ZONE);
            }
            newUser.setWorkingDayStartTime(rs.getString("WORKING_DAY_START_TIME"));
            newUser.setWorkingDayEndTime(rs.getString("WORKING_DAY_END_TIME"));
            newUser.setSumLimitFrom(rs.getBigDecimal("SUM_LIMIT_FROM"));
            newUser.setSumLimitTo(rs.getBigDecimal("SUM_LIMIT_TO"));
            newUser.setExternalPhone(rs.getString("EXTERNAL_NUMBER"));
            newUser.setInternalPhone(rs.getString("INTERNAL_NUMBER"));
            newUser.setUseInternalPhoneForC2C(Optional.ofNullable(rs.getBigDecimal("USE_INTERNAL_NUMBER_C2C"))
                    .map(d -> !BigDecimal.ZERO.equals(d))
                    .orElse(false));
            newUser.setPersonnelNumber(rs.getString("PERSONNEL_NUMBER"));
            newUser.setSubdivision(rs.getString("SUBDIVISION"));
            LocalDate absenceStart = Optional.ofNullable(rs.getTimestamp("ABSENCE_START_DATE"))
                    .map(Timestamp::toLocalDateTime)
                    .map(LocalDateTime::toLocalDate)
                    .orElse(null);
            LocalDate absenceEnd = Optional.ofNullable(rs.getTimestamp("ABSENCE_END_DATE"))
                    .map(Timestamp::toLocalDateTime)
                    .map(LocalDateTime::toLocalDate)
                    .orElse(null);
            if (absenceStart != null || absenceEnd != null) {
                AbsencePeriod absencePeriod = new AbsencePeriod(absenceStart, absenceEnd);
                newUser.getAbsence().add(absencePeriod);
            }
            return newUser;
        }, trimToNull(id), trimToNull(sberPdi));

        if (users.isEmpty()) {
            log.warn("Пользователь по id: {} или pdi: {} не найден", id, sberPdi);
            return null;
        }

        User user;
        if (users.size() == 1) {
            // Покрывает кейсы ИФТ, когда у пользователя нет sperPdi и он находится запросом логину
            user = users.get(0);
            log.info("Пользователь найден по id: {} или pdi: {}", id, sberPdi);
        } else {
            log.warn("Найдено больше одного пользователя по id: {} или pdi: {}", id, sberPdi);
            // Ищем пользователя сначала по полному совпадению, затем по совпадению только sberPdi
            user = users.stream()
                    .filter(usr -> StringUtils.equalsIgnoreCase(usr.getId(), id)
                            && StringUtils.equalsIgnoreCase(usr.getSberPdi(), sberPdi)).findFirst()
                    .orElse(
                            users.stream()
                                    .filter(usr -> StringUtils.equalsIgnoreCase(usr.getSberPdi(), sberPdi)).findFirst()
                                    .orElse(null)
                    );

        }
        if (isNull(user)) {
            // Не должно быть достижимо, так как означает ACT_ID_USER.ID_ не уникален
            log.error("Среди {} найденных по id: {} или pdi: {} пользователей не удалось найти подходящего", users.size(), id, sberPdi);
            return null;
        }


        String roleSql = """
                select u.ID_ as USER_ID, r.NAME from ACT_ID_USER u
                join V_USER_ROLES ur on ur.ID_ = u.ID_
                join ROLE r on r.ID = ur.R_ID
                where upper(u.ID_) = upper(?)
                """;
        jdbc.query(roleSql,
                ps -> ps.setString(1, trimToNull(user.getId())),
                rs -> {
                    user.getRoles().add(rs.getString("NAME"));
                });
        String creditTypeSql = """
                select u.ID_ as USER_ID, p.CODE from ACT_ID_USER u
                join USER_PROCESSING_PATH up on up.USER_ID = u.ID_
                join DICT_PROCESSING_PATH p on p.ID = up.PROCESSING_PATH_ID
                where upper(u.ID_) = upper(?)
                """;
        jdbc.query(creditTypeSql,
                ps -> ps.setString(1, trimToNull(user.getId())),
                rs -> {
                    user.getCreditTypes().add(rs.getString("CODE"));
                });
        return user;
    }
}
