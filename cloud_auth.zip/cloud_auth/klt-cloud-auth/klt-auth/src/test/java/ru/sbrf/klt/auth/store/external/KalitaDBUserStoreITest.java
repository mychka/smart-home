package ru.sbrf.klt.auth.store.external;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import ru.sbrf.klt.auth.AbstractTest;
import ru.sbrf.klt.auth.model.AbsencePeriod;
import ru.sbrf.klt.auth.model.User;
import ru.sbrf.klt.auth.store.UserStore;

import javax.sql.DataSource;

import static org.junit.jupiter.api.Assertions.*;

class KalitaDBUserStoreITest extends AbstractTest {

    @Autowired
    @Qualifier("Kalita")
    UserStore userStore;

    @Autowired
    @Qualifier("KalitaDataSource")
    DataSource dataSource;

    @BeforeEach
    void setUp() {
        JdbcTemplate jdbc = new JdbcTemplate(dataSource);
        jdbc.update("delete from V_USER_ROLES");
        jdbc.update("delete from ACT_ID_USER");
        jdbc.update("delete from ROLE");
        jdbc.update("delete from DICT_TIMEZONE");
        jdbc.update("delete from USER_SETTLEMENT");
        jdbc.update("delete from USER_PROCESSING_PATH");
        jdbc.update("delete from INTRABANK_PHONE_NUMBER");
        jdbc.update("delete from DICT_SUBDIVISION");
        jdbc.update("insert into ACT_ID_USER(ID_, SBER_PDI, EMAIL_, LAST_, FIRST_, MIDDLE_NAME_, PERSONNEL_NUMBER, " +
                "                                 SUBDIVISION_ID, ABSENCE_START_DATE, ABSENCE_END_DATE, INTRABANK_EMAIL_ID)\n" +
                "values('admin', '000001', 'admin@klt', 'Калита', 'Иван', 'Данилович', '012345678', 2, " +
                "       parsedatetime('17-02-2023 09:00:00', 'dd-MM-yyyy hh:mm:ss'), parsedatetime('21-02-2023 09:00:00', 'dd-MM-yyyy hh:mm:ss'), 1)");
        jdbc.update("insert into ROLE(ID, NAME) values (1, 'SUPERUSER')");
        jdbc.update("insert into ROLE(ID, NAME) values (2, 'USER')");
        jdbc.update("insert into V_USER_ROLES values ('admin',1)");
        jdbc.update("insert into V_USER_ROLES values ('admin',2)");
        jdbc.update("insert into ACT_ID_USER(ID_, SBER_PDI, EMAIL_, LAST_, FIRST_, MIDDLE_NAME_) values('user', '000002', 'user@klt', 'Федоров', 'Федор', 'Федорович')");
        jdbc.update("insert into V_USER_ROLES values ('user',2)");
        jdbc.update("insert into ROLE(ID, NAME) values (3, 'Ассистент сотрудника урегулирования ФЛ')");
        jdbc.update("insert into ACT_ID_USER(ID_, SBER_PDI, EMAIL_, LAST_, FIRST_, MIDDLE_NAME_)\n" +
                "values('test', null, 'user@klt', 'Сидоров', 'Федор', 'Петрович')");
        jdbc.update("insert into V_USER_ROLES values ('test',3)");
        jdbc.update("insert into DICT_TIMEZONE(ID, CODE) values(1, 'UTC+02:00')");
        jdbc.update("insert into DICT_TIMEZONE(ID, CODE) values(2, 'UTC+03:00')");
        jdbc.update("insert into DICT_TIMEZONE(ID, CODE) values(3, 'UTC+12:00')");
        jdbc.update("insert into USER_SETTLEMENT(USER_ID, TIMEZONE_ID, WORKING_DAY_START_TIME, WORKING_DAY_END_TIME, SUM_LIMIT_FROM, SUM_LIMIT_TO)\n" +
                "values('admin', 1, '09:20', '18:20', 100000, 1000000)");
        jdbc.update("insert into USER_PROCESSING_PATH(USER_ID, PROCESSING_PATH_ID) values('admin', 1)");
        jdbc.update("insert into USER_PROCESSING_PATH(USER_ID, PROCESSING_PATH_ID) values('admin', 3)");
        jdbc.update("insert into INTRABANK_PHONE_NUMBER(ID, USER_ID, EXTERNAL_NUMBER, INTERNAL_NUMBER, USE_INTERNAL_NUMBER_C2C) " +
                "values (1, 'admin', '+7 (495) 123-45-67', '8-11111111', 1)");
        jdbc.update("insert into DICT_SUBDIVISION(ID, CODE, DESCRIPTION, SHORT_DESCRIPTION) " +
                "values (1, 'BUR_GOSB_BB', 'Бурятское отделение №8601', 'Бурятское ГОСБ')");
        jdbc.update("insert into DICT_SUBDIVISION(ID, CODE, DESCRIPTION, SHORT_DESCRIPTION) " +
                "values (2, 'CHI_GOSB_BB', 'Читинское отделение №8600', 'Читинское ГОСБ')");
    }

    @Test
    void canGetUserByIdIgnoreCase() {
        User user = userStore.findByIdIgnoreCaseOrSberPdi("aDmiN", "000001");

        assertNotNull(user);
        assertEquals("admin", user.getId());
        assertEquals("000001", user.getSberPdi());
        assertEquals("Калита", user.getLastName());
        assertEquals("Иван", user.getFirstName());
        assertEquals("Данилович", user.getMiddleName());
        assertEquals("admin@admin.ru", user.getEmail());
        assertFalse(user.isDeleted());
        assertEquals("UTC+02:00", user.getTimeZone());
        assertEquals("09:20", user.getWorkingDayStartTime());
        assertEquals("18:20", user.getWorkingDayEndTime());
        assertEquals("100000", user.getSumLimitFrom().stripTrailingZeros().toPlainString());
        assertEquals("1000000", user.getSumLimitTo().stripTrailingZeros().toPlainString());
        assertEquals("+7 (495) 123-45-67", user.getExternalPhone());
        assertEquals("8-11111111", user.getInternalPhone());
        assertTrue(user.isUseInternalPhoneForC2C());
        assertEquals("012345678", user.getPersonnelNumber());
        assertEquals("CHI_GOSB_BB", user.getSubdivision());
        assertEquals(2, user.getRoles().size());
        assertTrue(user.getRoles().contains("SUPERUSER"));
        assertTrue(user.getRoles().contains("USER"));

        assertEquals(1, user.getAbsence().size());
        AbsencePeriod absencePeriod = user.getAbsence().get(0);
        assertEquals("From 17-02-2023 to 21-02-2023", absencePeriod.toString());

        assertEquals(2, user.getCreditTypes().size());
        assertTrue(user.getCreditTypes().contains("1"));
        assertTrue(user.getCreditTypes().contains("3"));
    }

    @Test
    @DisplayName("Проверяем выборку пользователя у которого есть id, но пустой pdi")
    void canGetUserByIdAndSberPdi() {
        User user = userStore.findByIdIgnoreCaseOrSberPdi("test", "test");

        assertNotNull(user);
        assertEquals("Сидоров", user.getLastName());
        assertFalse(user.isDeleted());
        assertEquals(1, user.getRoles().size());
        assertTrue(user.getRoles().contains("Ассистент сотрудника урегулирования ФЛ"));
        assertEquals(0, user.getAbsence().size());
    }

    @Test
    void cantGetUserByEmptyIdAndEmptySberPdi() {
        User user = userStore.findByIdIgnoreCaseOrSberPdi(" ", "  ");
        assertNull(user);
    }

    @Test
    void cantGetUserByNullIdAndNullSberPdi() {
        User user = userStore.findByIdIgnoreCaseOrSberPdi(null, null);
        assertNull(user);
    }
}