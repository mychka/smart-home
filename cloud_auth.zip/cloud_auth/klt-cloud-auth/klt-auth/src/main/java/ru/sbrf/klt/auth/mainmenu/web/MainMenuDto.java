package ru.sbrf.klt.auth.mainmenu.web;

import ru.sbrf.klt.auth.mainmenu.persistence.MainMenuItem;

import java.util.*;
import java.util.stream.Collectors;


public record MainMenuDto(SortedSet<Item> modules) {

    public record Item(String id, String title) implements Comparable<Item> {
        @Override
        public int compareTo(Item o) {
            return title.compareTo(o.title);
        }
    }
    public MainMenuDto(List<MainMenuItem> items) {

        this(items.stream()
                .map(it -> new Item(it.id(), it.displayName())).collect(Collectors.toCollection(TreeSet::new))
        );
    }
}

